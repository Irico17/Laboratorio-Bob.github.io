

DATABASE_URL = "postgresql://admin:SuperSecret123@localhost:5432/todos_db"



API_KEY = "sk_live_abc123xyz789_this_is_a_secret_key"

# Used for session management and should be randomly generated
SECRET_KEY = "my-super-secret-key-12345"


AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"


EMAIL_USERNAME = "admin@example.com"
EMAIL_PASSWORD = "EmailPassword123!"

# Additional configuration
DEBUG = True  
TESTING = False


JWT_SECRET_KEY = "jwt-secret-key-not-secure"

# Made with Bob

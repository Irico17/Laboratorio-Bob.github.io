---
name: security-audit
description: Perform a focused security audit looking for vulnerabilities, credential leaks, injection risks, and unsafe defaults
---

# Security Audit Skill

You are a security engineer. Perform a focused security audit on the provided code changes. Concentrate exclusively on security risks.

## Security Rules

- Flag secrets, credentials, tokens, private keys, connection strings, or passwords committed to source code, logs, fixtures, or configuration files.
- Flag command execution, SQL queries, template rendering, file paths, redirects, or HTTP requests that use untrusted input without validation or safe APIs.
- Authentication checks must happen before protected actions. Authorization checks must verify the caller can access the specific resource being changed or read.
- Sensitive data should not be logged, returned in error messages, stored in client-visible state, or exposed in telemetry.
- External dependencies, container images, and actions should be pinned or intentionally versioned. Flag untrusted scripts downloaded and executed at runtime.
- Defaults should be safe. Flag debug mode, permissive CORS, disabled TLS verification, public buckets, broad IAM permissions, or bypass flags enabled by default.

## Output Format

Return a Markdown report with this structure:

```markdown
# BobShell Security Audit

## Risk Level

Overall risk: critical | high | medium | low | clean

## Vulnerabilities Found

For each vulnerability:

### <short title>

- Severity: critical | high | medium | low
- File: <path>
- CWE: <CWE ID if applicable>
- Evidence: <code snippet or description>
- Remediation: <specific fix>

## Summary

Brief conclusion with prioritized action items.
```

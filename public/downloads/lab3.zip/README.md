# mini-auth · proyecto de práctica (Laboratorio 3)

Una pequeña API de autenticación en **Python puro** (sólo `http.server` + `sqlite3`),
escrita a propósito como un **único archivo monolítico** (`app.py`).

Es el punto de partida del **Laboratorio 3 — Arquitectura & Skills**: usarás a Bob para
analizar y mejorar su diseño, primero "crudo" y luego guiado por una Skill que tú crearás.

## Ejecutar

```bash
python3 app.py        # arranca en http://localhost:8000
```

## Qué está mal (a propósito)

- Sin separación de capas: HTTP, lógica de negocio y acceso a datos en la misma clase.
- `do_POST` con múltiples responsabilidades (viola el principio de responsabilidad única).
- Estado global (una conexión compartida) y código imposible de testear por unidades.
- Contraseñas en texto plano y SQL por concatenación de strings.

> Este repo es **independiente** del laboratorio de Bitbucket Pipelines (Lab 4), para
> mantener el ejercicio de arquitectura limpio y enfocado.

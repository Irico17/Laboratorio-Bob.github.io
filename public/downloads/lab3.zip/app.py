import json
from http.server import BaseHTTPRequestHandler, HTTPServer
import auth
import database

# Variables de configuración globales
PORT = 8000
DEBUG_MODE = True
SESSION_TIMEOUT = 300

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        data = json.loads(self.rfile.read(length) or b"{}")
        username = data.get("username", "")
        password = data.get("password", "")

        if self.path == "/register":
            # Delegar a auth
            success = auth.register_user(username, password)
            if success:
                # Log de auditoría directo mezclado
                database.log_action(f"Usuario registrado: {username}")
                self.respond(201, {"status": "created"})
            else:
                self.respond(400, {"error": "registro fallido"})

        elif self.path == "/login":
            success = auth.login_user(username, password)
            if success:
                self.respond(200, {"status": "ok", "token": "session-active-123"})
            else:
                self.respond(401, {"error": "credenciales invalidas"})
        else:
            self.respond(404, {"error": "not found"})

    def do_GET(self):
        if self.path == "/status":
            # Mezcla HTML con API (Violación MVC)
            html = f"<html><body><h1>Servidor Activo</h1><p>Debug: {DEBUG_MODE}</p></body></html>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(html.encode())
        else:
            self.respond(404, {"error": "not found"})

    def respond(self, status, payload):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(body)

def get_server_config():
    return {"debug": DEBUG_MODE, "timeout": SESSION_TIMEOUT}

if __name__ == "__main__":
    database.init_db()
    print(f"Iniciando servidor en http://localhost:{PORT}")
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()

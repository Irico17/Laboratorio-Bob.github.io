# Copilot Instructions

## Build, Test & Lint

```bash
# No package install step is required for the POC scripts.

# Validate shell syntax
bash -n scripts/bobshell-pr-review.sh
bash -n tests/mock-bobshell.sh
bash -n tests/run-local-poc-test.sh

# Run all tests / smoke checks
bash tests/run-local-poc-test.sh

# There is only one smoke test today; use shell syntax checks above for single-file validation.
```

## Architecture

This repository is a Bitbucket Pipelines POC for running BobShell PR reviews with an external rules repository.

The entry point is `bitbucket-pipelines.yml`, which runs `scripts/bobshell-pr-review.sh` on pull request builds. The wrapper script clones or copies rules, obtains the PR diff, assembles `.bobshell/prompt.md`, runs BobShell through `BOBSHELL_COMMAND`, writes `bobshell-review.md`, optionally posts a Bitbucket PR comment, and optionally fails on configured severity.

`bobshell-rules/` is a starter template for the separate rules repository. In real use, copy that folder into its own Bitbucket or GitHub repository and point `BOBSHELL_RULES_REPO_URL` at it.

`tests/run-local-poc-test.sh` validates the integration without Bitbucket by using `tests/mock-bobshell.sh`, `tests/fixtures/sample.diff`, and `BOBSHELL_RULES_LOCAL_PATH`.

## Key Conventions

- Keep the wrapper script dependency-light: Bash, Git, curl, and Python 3 or Node.js only for JSON escaping when posting comments.
- `BOBSHELL_COMMAND` must be non-interactive, read the prompt from stdin, write Markdown to stdout, and return non-zero on execution failure.
- Use `BOBSHELL_OUTPUT_MODE=artifact|comment|both` to choose whether reviews are saved, commented on the PR, or both.
- Keep blocking behavior disabled for first integrations with `BOBSHELL_FAIL_ON=never`; raise it later after review quality is trusted.
- Generated runtime files belong in `.bobshell/` and `bobshell-review.md`; they are ignored by Git.

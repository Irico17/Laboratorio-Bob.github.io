# BobShell Bitbucket Pipeline POC Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a testable Bitbucket Pipelines POC that runs BobShell against PR diffs using an external rules repository and produces both a Markdown artifact and optional Bitbucket PR comment.

**Architecture:** The POC uses a thin CI wrapper script as the integration boundary between Bitbucket Pipelines, a rules repository, and BobShell. Rules are Markdown files cloned or copied at runtime, then merged with PR metadata and diff content into a prompt passed to a configurable non-interactive `BOBSHELL_COMMAND`. Output is written to an artifact and optionally posted to the PR through the Bitbucket REST API.

**Tech Stack:** Bitbucket Pipelines YAML, POSIX shell/Bash, Git, curl, Python 3 or Node.js for JSON escaping, Markdown rule files.

---

## File Structure

- Create `bitbucket-pipelines.yml`: PR pipeline entry point.
- Create `scripts/bobshell-pr-review.sh`: CI wrapper that loads rules, gets diffs, calls BobShell, writes artifact, posts comments, and applies severity gating.
- Create `bobshell-rules/README.md`: explains how to turn the folder into the separate rules repository.
- Create `bobshell-rules/prompts/review-pr.md`: prompt contract for BobShell review.
- Create `bobshell-rules/rules/pr-standards.md`: PR quality rules.
- Create `bobshell-rules/rules/architecture.md`: architecture review rules.
- Create `bobshell-rules/rules/security.md`: security review rules.
- Create `bobshell-rules/rules/design-patterns.md`: design pattern review rules.
- Create `tests/fixtures/sample.diff`: local diff fixture.
- Create `tests/mock-bobshell.sh`: deterministic fake BobShell command for local test.
- Create `tests/run-local-poc-test.sh`: smoke test that runs the wrapper without Bitbucket.
- Create `docs/bobshell-bitbucket-poc.md`: setup, configuration, and usage guide.

## Task 1: Create the CI Wrapper

**Files:**
- Create: `scripts/bobshell-pr-review.sh`

- [x] **Step 1: Add strict shell script scaffold**

```bash
#!/usr/bin/env bash
set -Eeuo pipefail
```

- [x] **Step 2: Add logging and command checks**

```bash
log() { printf '[bobshell-review] %s\n' "$*"; }
die() { printf '[bobshell-review] ERROR: %s\n' "$*" >&2; exit 1; }
need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"; }
```

- [x] **Step 3: Add configurable defaults**

```bash
WORK_DIR="${BOBSHELL_WORK_DIR:-.bobshell}"
RULES_DIR="$WORK_DIR/rules-repo"
PROMPT_FILE="$WORK_DIR/prompt.md"
DIFF_FILE="${BOBSHELL_DIFF_FILE:-$WORK_DIR/pr.diff}"
REVIEW_FILE="${BOBSHELL_REVIEW_FILE:-bobshell-review.md}"
OUTPUT_MODE="${BOBSHELL_OUTPUT_MODE:-both}"
FAIL_ON="${BOBSHELL_FAIL_ON:-never}"
RULES_REF="${BOBSHELL_RULES_REF:-main}"
REQUIRE_COMMAND="${BOBSHELL_REQUIRE_COMMAND:-false}"
```

- [x] **Step 4: Implement rules checkout**

Rules checkout supports a local path for tests and a Git URL for CI:

```bash
if [ -n "${BOBSHELL_RULES_LOCAL_PATH:-}" ]; then
  cp -R "$BOBSHELL_RULES_LOCAL_PATH" "$RULES_DIR"
elif [ -n "${BOBSHELL_RULES_REPO_URL:-}" ]; then
  git clone --depth 1 --branch "$RULES_REF" "$BOBSHELL_RULES_REPO_URL" "$RULES_DIR"
else
  die "Set BOBSHELL_RULES_REPO_URL or BOBSHELL_RULES_LOCAL_PATH"
fi
```

- [x] **Step 5: Implement PR diff collection**

The wrapper first uses `BOBSHELL_DIFF_FILE`, then Bitbucket API, then local Git diff:

```bash
if [ -f "$DIFF_FILE" ]; then
  log "Using existing diff file: $DIFF_FILE"
elif has_bitbucket_pr_context; then
  fetch_bitbucket_diff
else
  fetch_local_diff
fi
```

- [x] **Step 6: Implement prompt assembly**

The prompt includes metadata, rule files, optional prompt template, and diff:

```bash
{
  printf '# BobShell Pull Request Review Request\n\n'
  printf '## Pull Request Context\n\n'
  printf -- '- Workspace: %s\n' "${BITBUCKET_WORKSPACE:-unknown}"
  printf -- '- Repository: %s\n' "${BITBUCKET_REPO_SLUG:-unknown}"
  printf -- '- Pull Request: %s\n' "${BITBUCKET_PR_ID:-local}"
  printf '\n## Rules\n\n'
  find "$RULES_DIR/rules" -type f -name '*.md' | sort | while read -r file; do
    printf '\n### %s\n\n' "$(basename "$file")"
    cat "$file"
    printf '\n'
  done
  printf '\n## Pull Request Diff\n\n```diff\n'
  cat "$DIFF_FILE"
  printf '\n```\n'
} > "$PROMPT_FILE"
```

- [x] **Step 7: Execute BobShell or dry-run fallback**

Use `BOBSHELL_COMMAND` when configured. Otherwise, create a dry-run artifact unless `BOBSHELL_REQUIRE_COMMAND=true`.

```bash
if [ -n "${BOBSHELL_COMMAND:-}" ]; then
  sh -c "$BOBSHELL_COMMAND" < "$PROMPT_FILE" > "$REVIEW_FILE"
else
  write_dry_run_review
fi
```

- [x] **Step 8: Add Bitbucket PR comment publishing**

When `BOBSHELL_OUTPUT_MODE=comment` or `both`, post a Markdown comment with curl:

```bash
curl -fsS -u "$BITBUCKET_USERNAME:$BITBUCKET_APP_PASSWORD" \
  -H 'Content-Type: application/json' \
  -X POST \
  "https://api.bitbucket.org/2.0/repositories/$BITBUCKET_WORKSPACE/$BITBUCKET_REPO_SLUG/pullrequests/$BITBUCKET_PR_ID/comments" \
  --data-binary "$payload_file"
```

- [x] **Step 9: Add severity gate**

The script supports `BOBSHELL_FAIL_ON=never|critical|high|medium|low` and scans the review output for severity markers.

- [x] **Step 10: Run syntax check**

Run:

```bash
bash -n scripts/bobshell-pr-review.sh
```

Expected: exit code `0`.

## Task 2: Create Rules Repository Template

**Files:**
- Create: `bobshell-rules/README.md`
- Create: `bobshell-rules/prompts/review-pr.md`
- Create: `bobshell-rules/rules/pr-standards.md`
- Create: `bobshell-rules/rules/architecture.md`
- Create: `bobshell-rules/rules/security.md`
- Create: `bobshell-rules/rules/design-patterns.md`

- [x] **Step 1: Document rules repo purpose**

`bobshell-rules/README.md` explains that this folder should become a separate repository for real use.

- [x] **Step 2: Add BobShell review prompt contract**

`prompts/review-pr.md` defines the required Markdown output sections and severity labels.

- [x] **Step 3: Add PR standards rules**

Rules cover PR scope, title/description quality, reviewability, and migration/config documentation.

- [x] **Step 4: Add architecture rules**

Rules cover boundaries, dependency direction, layering, infrastructure access, and coupling.

- [x] **Step 5: Add security rules**

Rules cover secrets, injection risk, authz/authn, dependency risk, logging, and unsafe defaults.

- [x] **Step 6: Add design pattern rules**

Rules cover consistency, unnecessary abstraction, duplicated logic, error handling patterns, and transactional behavior.

## Task 3: Create Bitbucket Pipeline

**Files:**
- Create: `bitbucket-pipelines.yml`

- [x] **Step 1: Add PR trigger**

```yaml
pipelines:
  pull-requests:
    '**':
      - step:
          name: BobShell PR review
```

- [x] **Step 2: Run wrapper script**

```yaml
script:
  - chmod +x scripts/bobshell-pr-review.sh
  - ./scripts/bobshell-pr-review.sh
```

- [x] **Step 3: Save artifacts**

```yaml
artifacts:
  - bobshell-review.md
  - .bobshell/**
```

## Task 4: Create Local Test Harness

**Files:**
- Create: `tests/fixtures/sample.diff`
- Create: `tests/mock-bobshell.sh`
- Create: `tests/run-local-poc-test.sh`

- [x] **Step 1: Add sample diff**

The fixture contains a simple insecure JavaScript change so the mock can produce deterministic output.

- [x] **Step 2: Add mock BobShell**

The mock reads stdin and writes a Markdown review with a known marker.

- [x] **Step 3: Add smoke test**

The test sets:

```bash
export BOBSHELL_RULES_LOCAL_PATH="$REPO_ROOT/bobshell-rules"
export BOBSHELL_DIFF_FILE="$REPO_ROOT/tests/fixtures/sample.diff"
export BOBSHELL_COMMAND="'$REPO_ROOT/tests/mock-bobshell.sh'"
export BOBSHELL_OUTPUT_MODE="artifact"
export BOBSHELL_REVIEW_FILE="$REPO_ROOT/bobshell-review.md"
```

Then runs:

```bash
"$REPO_ROOT/scripts/bobshell-pr-review.sh"
```

Expected: `bobshell-review.md` exists and contains `Mock BobShell Review`.

## Task 5: Create Setup Documentation

**Files:**
- Create: `docs/bobshell-bitbucket-poc.md`

- [x] **Step 1: Document quick local test**

```bash
bash tests/run-local-poc-test.sh
```

- [x] **Step 2: Document Bitbucket variables**

Include required and optional variables:

```text
BOBSHELL_COMMAND
BOBSHELL_RULES_REPO_URL
BOBSHELL_RULES_REF
BOBSHELL_OUTPUT_MODE
BOBSHELL_FAIL_ON
BITBUCKET_USERNAME
BITBUCKET_APP_PASSWORD
```

- [x] **Step 3: Document same-workspace rules repo setup**

Explain how to copy `bobshell-rules/` into its own Bitbucket repository and point `BOBSHELL_RULES_REPO_URL` to it.

- [x] **Step 4: Document output mode selection**

Explain `artifact`, `comment`, and `both`.

- [x] **Step 5: Document future MCP extension**

State that MCP is not required for the POC but is the right next layer for richer PR operations.

## Task 6: Validate the POC

**Files:**
- Validate: `scripts/bobshell-pr-review.sh`
- Validate: `tests/run-local-poc-test.sh`
- Validate: `bitbucket-pipelines.yml`

- [x] **Step 1: Run shell syntax checks**

```bash
bash -n scripts/bobshell-pr-review.sh
bash -n tests/mock-bobshell.sh
bash -n tests/run-local-poc-test.sh
```

Expected: all commands exit `0`.

- [x] **Step 2: Run local smoke test**

```bash
bash tests/run-local-poc-test.sh
```

Expected output includes:

```text
Local BobShell POC test passed.
```

- [x] **Step 3: Confirm artifact exists**

```bash
test -f bobshell-review.md
grep -q 'Mock BobShell Review' bobshell-review.md
```

Expected: both commands exit `0`.

## Self-Review

- Spec coverage: the plan implements rules repo loading, BobShell execution, artifacts, optional PR comments, configurable output mode, severity gate, and local testability.
- Placeholder scan: no open implementation placeholders remain in the POC files.
- Type and naming consistency: environment variables, paths, and script function names are consistent across docs, pipeline, and tests.

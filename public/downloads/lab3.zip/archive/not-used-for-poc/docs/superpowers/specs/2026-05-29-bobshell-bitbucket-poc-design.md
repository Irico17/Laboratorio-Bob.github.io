# BobShell Bitbucket Pipeline POC Design

## Objective

Build a minimal, testable proof of concept that runs BobShell from Bitbucket Pipelines to review pull requests using rules stored in a separate repository. The POC must support both review artifacts and pull request comments, while keeping the rules repository source configurable for future use with another Bitbucket workspace, GitHub, or a public repository.

## Recommended POC Scope

The POC uses two repositories:

1. **Application repository**: contains `bitbucket-pipelines.yml`, a CI wrapper script, and documentation.
2. **Rules repository**: contains Markdown rules and a prompt template that BobShell consumes during PR review.

For the first test, the rules repository should live in the same Bitbucket workspace as the application repository. This minimizes authentication complexity because Bitbucket Pipelines can reuse workspace-level credentials or a single app password. The design still supports an external Git URL through `BOBSHELL_RULES_REPO_URL`.

## Runtime Flow

1. A pull request triggers Bitbucket Pipelines.
2. The pipeline runs `scripts/bobshell-pr-review.sh`.
3. The script clones or copies the configured rules repository.
4. The script obtains the PR diff from the Bitbucket API when PR metadata and credentials are available.
5. If API access is not configured, it falls back to a local `git diff`.
6. The script builds a review prompt from:
   - PR metadata
   - `rules/*.md`
   - `prompts/review-pr.md`
   - PR diff
7. The script executes BobShell through a configurable `BOBSHELL_COMMAND`.
8. The script writes `bobshell-review.md`.
9. If configured, the script posts the review back to the Bitbucket pull request as a comment.
10. The script optionally fails the pipeline based on configured severity thresholds.

## Components

### Bitbucket Pipeline

`bitbucket-pipelines.yml` defines a PR pipeline that runs the BobShell review step and stores `bobshell-review.md` plus `.bobshell/**` as artifacts.

The pipeline does not hardcode secrets. It expects credentials and BobShell configuration through Bitbucket repository or workspace variables.

### CI Wrapper

`scripts/bobshell-pr-review.sh` is the integration boundary. It owns:

- input validation
- rules repository checkout
- diff collection
- prompt assembly
- BobShell execution
- artifact generation
- optional Bitbucket PR commenting
- optional fail-on-severity behavior

BobShell itself remains a replaceable dependency. The wrapper accepts any non-interactive command through `BOBSHELL_COMMAND`, allowing the same integration to work with a BobShell binary, Docker wrapper, npm package, or self-hosted runner installation.

### Rules Repository Template

`bobshell-rules/` is a starter repository structure that can be copied into a dedicated Bitbucket repository. It includes:

- PR standards
- architecture rules
- security review rules
- design pattern rules
- the review prompt contract

The rules are intentionally Markdown-based so they can evolve without changing the CI wrapper.

### Local Test Harness

`tests/run-local-poc-test.sh` validates the integration without Bitbucket or real BobShell by using:

- a local rules repository path
- a fixture diff
- a mock BobShell command
- artifact-only output mode

This proves the wrapper can assemble the prompt, run a command, write the review artifact, and enforce the expected output path.

## Configuration

Required for real BobShell execution:

- `BOBSHELL_COMMAND`: non-interactive command that reads the generated prompt from stdin and writes Markdown review output to stdout.

Required for cloning a remote rules repository:

- `BOBSHELL_RULES_REPO_URL`: Git URL for the rules repository.
- `BOBSHELL_RULES_REF`: branch, tag, or commit to review against. Defaults to `main`.

Required for Bitbucket PR comments:

- `BITBUCKET_USERNAME`
- `BITBUCKET_APP_PASSWORD`
- `BITBUCKET_WORKSPACE`
- `BITBUCKET_REPO_SLUG`
- `BITBUCKET_PR_ID`

Optional behavior:

- `BOBSHELL_OUTPUT_MODE`: `artifact`, `comment`, or `both`. Defaults to `both`.
- `BOBSHELL_FAIL_ON`: `never`, `critical`, `high`, `medium`, or `low`. Defaults to `never`.
- `BOBSHELL_REQUIRE_COMMAND`: `true` fails when BobShell is not configured. Defaults to `false` so the POC can still validate pipeline wiring.
- `BOBSHELL_REVIEW_FILE`: review artifact path. Defaults to `bobshell-review.md`.
- `BOBSHELL_DIFF_FILE`: path to a precomputed diff file.

## Error Handling

The wrapper exits immediately on shell errors and missing required commands. It does not print secrets. It only posts comments when both output mode and Bitbucket PR credentials are present.

If BobShell is not configured and `BOBSHELL_REQUIRE_COMMAND=false`, the script writes a clearly marked dry-run review artifact. This keeps the POC runnable before the final BobShell installation mechanism is known.

## Testing Strategy

The POC includes a local smoke test:

```bash
bash tests/run-local-poc-test.sh
```

The test verifies:

- script syntax
- prompt generation
- local rules repository loading
- mock BobShell execution
- review artifact creation
- output contains expected review text

The Bitbucket end-to-end test is performed by opening a pull request after configuring repository variables.

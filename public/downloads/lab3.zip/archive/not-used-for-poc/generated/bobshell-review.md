# Mock BobShell Review

## Summary

The mock reviewer received 4915 characters of prompt content and produced a deterministic review for the local POC.

## Findings

### Hardcoded secret in sample diff

- Severity: high
- File: src/example.js
- Rule: security.md
- Evidence: The diff contains a hardcoded password string.
- Recommendation: Read secrets from a secure runtime secret store and avoid logging sensitive values.

## Positive Notes

The CI wrapper successfully loaded rules and passed the PR diff to the BobShell command.

## Final Recommendation

Request changes

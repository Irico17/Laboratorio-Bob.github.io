#!/usr/bin/env bash
# bobshell-llm-adapter.sh
#
# Drop-in BOBSHELL_COMMAND for CI environments where BobShell is not installed.
# Reads the prompt from stdin, calls an LLM API, writes Markdown to stdout.
#
# No BobShell installation required — just add an API key to your Bitbucket
# repository variables and set:
#   BOBSHELL_COMMAND=bash scripts/bobshell-llm-adapter.sh
#
# Supported providers (checked in this order):
#   1. Anthropic Claude  (ANTHROPIC_API_KEY)  – default model: claude-3-5-haiku-20241022
#   2. OpenAI            (OPENAI_API_KEY)     – default model: gpt-4o-mini
#
# Optional overrides:
#   LLM_MODEL       – override the default model name
#   LLM_MAX_TOKENS  – max response tokens (default: 4096)

set -Eeuo pipefail

die() { printf '[bobshell-llm] ERROR: %s\n' "$*" >&2; exit 1; }

command -v python3 >/dev/null 2>&1 || die "python3 is required"

PROMPT_TMP=$(mktemp)
trap 'rm -f "$PROMPT_TMP"' EXIT

cat > "$PROMPT_TMP"
[ -s "$PROMPT_TMP" ] || die "Empty prompt received on stdin"

MAX_TOKENS="${LLM_MAX_TOKENS:-4096}"

# ── Anthropic ────────────────────────────────────────────────────────────────

call_anthropic() {
  MODEL="${LLM_MODEL:-claude-3-5-haiku-20241022}"
  python3 - "$PROMPT_TMP" "$MODEL" "$MAX_TOKENS" <<'PYEOF'
import sys, json, urllib.request, urllib.error, os

prompt_file = sys.argv[1]
model       = sys.argv[2]
max_tokens  = int(sys.argv[3])

prompt = open(prompt_file, encoding="utf-8").read()

payload = json.dumps({
    "model": model,
    "max_tokens": max_tokens,
    "messages": [{"role": "user", "content": prompt}],
}).encode()

req = urllib.request.Request(
    "https://api.anthropic.com/v1/messages",
    data=payload,
    headers={
        "x-api-key": os.environ["ANTHROPIC_API_KEY"],
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    },
)

try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())
    print(data["content"][0]["text"])
except urllib.error.HTTPError as exc:
    body = exc.read().decode()
    print(f"[bobshell-llm] Anthropic API error {exc.code}: {body}", file=sys.stderr)
    sys.exit(1)
PYEOF
}

# ── OpenAI ────────────────────────────────────────────────────────────────────

call_openai() {
  MODEL="${LLM_MODEL:-gpt-4o-mini}"
  python3 - "$PROMPT_TMP" "$MODEL" "$MAX_TOKENS" <<'PYEOF'
import sys, json, urllib.request, urllib.error, os

prompt_file = sys.argv[1]
model       = sys.argv[2]
max_tokens  = int(sys.argv[3])

prompt = open(prompt_file, encoding="utf-8").read()

payload = json.dumps({
    "model": model,
    "max_tokens": max_tokens,
    "messages": [{"role": "user", "content": prompt}],
}).encode()

req = urllib.request.Request(
    "https://api.openai.com/v1/chat/completions",
    data=payload,
    headers={
        "Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}",
        "Content-Type": "application/json",
    },
)

try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())
    print(data["choices"][0]["message"]["content"])
except urllib.error.HTTPError as exc:
    body = exc.read().decode()
    print(f"[bobshell-llm] OpenAI API error {exc.code}: {body}", file=sys.stderr)
    sys.exit(1)
PYEOF
}

# ── dispatch ─────────────────────────────────────────────────────────────────

if [ -n "${ANTHROPIC_API_KEY:-}" ]; then
  call_anthropic
elif [ -n "${OPENAI_API_KEY:-}" ]; then
  call_openai
else
  die "No LLM API key found. Set ANTHROPIC_API_KEY or OPENAI_API_KEY in Bitbucket repository/workspace variables."
fi

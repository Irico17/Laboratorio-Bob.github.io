#!/usr/bin/env bash
# bobshell-watsonx-adapter.sh
#
# Drop-in BOBSHELL_COMMAND that uses IBM watsonx.ai (IBM Granite models).
# This is the IBM-native adapter — it calls the same foundation models
# that power IBM Bob, using the public watsonx.ai REST API.
#
# Getting started (free tier):
#   1. Sign up at https://ibm.com/cloud (free IBMid)
#   2. Open https://dataplatform.cloud.ibm.com → create a watsonx.ai project
#   3. Go to IBM Cloud → Manage → Access (IAM) → API keys → create key
#   4. Find your project ID: Project → Manage → General → Project ID
#
# Required environment variables:
#   WATSONX_API_KEY    – IBM Cloud API key
#   WATSONX_PROJECT_ID – watsonx.ai project ID
#
# Optional environment variables:
#   WATSONX_URL        – Regional endpoint (default: https://us-south.ml.cloud.ibm.com)
#   WATSONX_MODEL      – Model ID (default: ibm/granite-3-8b-instruct)
#                        Other options: ibm/granite-34b-code-instruct
#                                       ibm/granite-20b-code-instruct-v2
#   WATSONX_MAX_TOKENS – Max new tokens in response (default: 4096)
#
# Usage (set this in Bitbucket repository variables):
#   BOBSHELL_COMMAND=bash scripts/bobshell-watsonx-adapter.sh

set -Eeuo pipefail

die() { printf '[bobshell-watsonx] ERROR: %s\n' "$*" >&2; exit 1; }
log() { printf '[bobshell-watsonx] %s\n' "$*" >&2; }

command -v python3 >/dev/null 2>&1 || die "python3 is required"

: "${WATSONX_API_KEY:?Set WATSONX_API_KEY (IBM Cloud API key) in Bitbucket repository variables}"
: "${WATSONX_PROJECT_ID:?Set WATSONX_PROJECT_ID (watsonx.ai project ID) in Bitbucket repository variables}"

WATSONX_URL="${WATSONX_URL:-https://us-south.ml.cloud.ibm.com}"
WATSONX_MODEL="${WATSONX_MODEL:-ibm/granite-3-8b-instruct}"
WATSONX_MAX_TOKENS="${WATSONX_MAX_TOKENS:-4096}"

# ── 1. Read prompt from stdin ─────────────────────────────────────────────────

PROMPT_TMP=$(mktemp)
trap 'rm -f "$PROMPT_TMP"' EXIT

cat > "$PROMPT_TMP"
[ -s "$PROMPT_TMP" ] || die "Empty prompt received on stdin"

log "Model: ${WATSONX_MODEL}"
log "Prompt size: $(wc -c < "$PROMPT_TMP") bytes"

# ── 2. Obtain IAM bearer token ────────────────────────────────────────────────

log "Requesting IAM token..."
IAM_TOKEN=$(python3 - "$WATSONX_API_KEY" <<'PYEOF'
import sys, json, urllib.request, urllib.error, urllib.parse

api_key = sys.argv[1]

data = urllib.parse.urlencode({
    "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
    "apikey": api_key,
}).encode()

req = urllib.request.Request(
    "https://iam.cloud.ibm.com/identity/token",
    data=data,
    headers={"Content-Type": "application/x-www-form-urlencoded"},
)

try:
    with urllib.request.urlopen(req) as resp:
        result = json.loads(resp.read())
    print(result["access_token"])
except urllib.error.HTTPError as exc:
    body = exc.read().decode()
    print(f"IAM token error {exc.code}: {body}", file=sys.stderr)
    sys.exit(1)
PYEOF
)

[ -n "$IAM_TOKEN" ] || die "Failed to obtain IAM token"
log "IAM token obtained."

# ── 3. Call watsonx.ai text generation ───────────────────────────────────────

log "Calling watsonx.ai text generation (${WATSONX_URL})..."
python3 - \
    "$PROMPT_TMP" \
    "$IAM_TOKEN" \
    "$WATSONX_URL" \
    "$WATSONX_MODEL" \
    "$WATSONX_MAX_TOKENS" \
    "$WATSONX_PROJECT_ID" \
    <<'PYEOF'
import sys, json, urllib.request, urllib.error

prompt_file = sys.argv[1]
iam_token   = sys.argv[2]
base_url    = sys.argv[3].rstrip("/")
model_id    = sys.argv[4]
max_tokens  = int(sys.argv[5])
project_id  = sys.argv[6]

prompt = open(prompt_file, encoding="utf-8", errors="replace").read()

# Truncate very long prompts to stay within token limits
# ~4 chars per token as a rough heuristic; leave room for response
MAX_PROMPT_CHARS = max_tokens * 3
if len(prompt) > MAX_PROMPT_CHARS:
    prompt = prompt[:MAX_PROMPT_CHARS] + "\n\n... (prompt truncated) ..."

payload = json.dumps({
    "model_id": model_id,
    "input": prompt,
    "parameters": {
        "decoding_method": "greedy",
        "max_new_tokens": max_tokens,
        "repetition_penalty": 1.05,
        "stop_sequences": [],
    },
    "project_id": project_id,
}).encode()

url = f"{base_url}/ml/v1/text/generation?version=2023-05-29"

req = urllib.request.Request(
    url,
    data=payload,
    headers={
        "Authorization": f"Bearer {iam_token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    },
)

try:
    with urllib.request.urlopen(req, timeout=300) as resp:
        result = json.loads(resp.read())
except urllib.error.HTTPError as exc:
    body = exc.read().decode()
    print(f"[bobshell-watsonx] watsonx.ai error {exc.code}: {body}", file=sys.stderr)
    sys.exit(1)

generated = result.get("results", [{}])[0].get("generated_text", "").strip()

if not generated:
    print("[bobshell-watsonx] watsonx.ai returned empty response", file=sys.stderr)
    sys.exit(1)

print(generated)
PYEOF

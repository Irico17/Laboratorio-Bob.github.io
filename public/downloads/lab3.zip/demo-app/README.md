# demo-app — API de autenticación (rama `dev`)

Versión **saboteada a propósito** para el Laboratorio 4: un único archivo
(`app.py`) en **Python puro** (sólo `http.server` + `sqlite3`, sin dependencias).

Problemas plantados (lo que Bob debe detectar y corregir):

- Contraseñas almacenadas en **texto plano**.
- **Inyección SQL** por concatenación de strings.
- Sin validación de entrada.
- Mensajes de error que **filtran si el usuario existe**.
- Sin separación de capas (HTTP + lógica + datos mezclados).

> La versión **bien estructurada** (objetivo) está en la rama `master`.

## Ejecutar

```bash
python3 demo-app/app.py     # arranca en http://localhost:8000
```

import sqlite3
import base64
# IMPORTACIÓN CIRCULAR: auth importa a app, y app importa a auth
import app

def encrypt_password(password):
    # Duplicidad: codifica en base64 en lugar de usar un hash real
    return base64.b64encode(password.encode()).decode()

def register_user(username, password):
    # MALA PRÁCTICA: Abre su propia base de datos separada 'users.db' en lugar de usar database.py
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)")
    
    # Inyección SQL por concatenación
    encrypted = encrypt_password(password)
    query = f"INSERT INTO users VALUES ('{username}', '{encrypted}')"
    cursor.execute(query)
    conn.commit()
    conn.close()
    return True

def login_user(username, password):
    # Acceso a variables de app.py (demuestra el acoplamiento circular)
    config = app.get_server_config()
    if config.get("debug"):
        print(f"Intentando login para: {username}")
        
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    
    # Inyección SQL
    encrypted = encrypt_password(password)
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{encrypted}'"
    cursor.execute(query)
    user = cursor.fetchone()
    conn.close()
    return user is not None

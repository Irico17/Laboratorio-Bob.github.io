import sqlite3

# MALA PRÁCTICA: Credenciales y API Keys críticas expuestas en texto plano (Hardcoded Secrets)
ADMIN_DB_USER = "db_admin_prod"
ADMIN_DB_PASSWORD = "SuperSecretDbPassword123!"
EXTERNAL_AUDIT_SERVICE_TOKEN = "sk_live_51HzABcDeFgHiJkLmNoPqRsTuVwXyZ"

# MALA PRÁCTICA: Se crea un archivo de base de datos diferente al de auth.py ('app.db' vs 'users.db')
DB_FILE = "app.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY, action TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)"
    )
    conn.commit()
    conn.close()

def log_action(action):
    conn = sqlite3.connect(DB_FILE)
    # Concatenación directa
    conn.execute(f"INSERT INTO audit_logs (action) VALUES ('{action}')")
    conn.commit()
    conn.close()

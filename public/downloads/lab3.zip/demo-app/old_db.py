# ARCHIVO DEPRECADO / HUÉRFANO
# Este código ya no se usa, pero quedó en el repositorio y causa ruido.

import sqlite3

def backup_db():
    # Código viejo e incompleto
    # conn = sqlite3.connect("backup.db")
    # print("Respaldo no implementado")
    pass

import base64

def format_user_data(username):
    # Otra duplicación de codificación base64, escrita de otra forma
    encoded = base64.b64encode(username.encode('utf-8'))
    return f"USER_{encoded.decode('utf-8')}"

def deprecated_hash(text):
    # Función sin uso que aumenta el desorden del repositorio
    return "".join(reversed(text))

# BobShell + Bitbucket Pipelines POC

Este documento explica como funciona el POC que integra IBM Bob Shell con Bitbucket Pipelines para revisar pull requests, generar artifacts y responder comandos tipo `/bob`.

## Resultado actual

El POC ya funciona para el flujo principal:

1. Se abre o actualiza un pull request en Bitbucket.
2. Bitbucket Pipelines crea un contenedor temporal.
3. El contenedor instala Bob Shell.
4. El script carga reglas desde `bobshell-rules/`.
5. Se genera el diff del PR con `git diff` local.
6. Bob Shell analiza el diff con las reglas.
7. Se genera el artifact `bobshell-review.md`.
8. Si existe `BOBSHELL_BB_TOKEN`, el review se publica como comentario en el PR.

## Variables necesarias

En Bitbucket, ir a **Repository settings > Pipelines > Repository variables**.

| Variable | Requerida | Uso |
|---|---:|---|
| `BOBSHELL_API_KEY` | Si | API key de Bob Shell con scope `Inference`. Permite ejecutar Bob en CI sin login interactivo. |
| `BOBSHELL_BB_TOKEN` | Si, para comentar PRs | Repository Access Token de Bitbucket. Se usa con `Authorization: Bearer <token>` para postear comentarios en el PR. |
| `BOBSHELL_COMMAND` | No | Comando para ejecutar Bob. Si no se define, el pipeline usa `bash scripts/bob-ci-runner.sh`. |
| `BOBSHELL_RULES_REPO_URL` | No | URL de otro repo con reglas. Si no se define, usa `bobshell-rules/` local. |
| `BOBSHELL_RULES_REF` | No | Rama/tag de las reglas externas. Default: `main`. |
| `BOBSHELL_FAIL_ON` | No | Umbral para fallar el pipeline segun severidad: `never`, `critical`, `high`, `medium`, `low`. Default: `never`. |

Las variables `BITBUCKET_WORKSPACE`, `BITBUCKET_REPO_SLUG`, `BITBUCKET_PR_ID`, `BITBUCKET_COMMIT`, `BITBUCKET_BRANCH` y similares las inyecta Bitbucket automaticamente durante el pipeline.

## Como funciona tecnicamente el review

### 1. Trigger del pipeline

`bitbucket-pipelines.yml` define:

```yaml
pipelines:
  pull-requests:
    '**':
      - step:
          name: BobShell PR Review
```

Eso significa que Bitbucket ejecuta el step cada vez que se crea o actualiza un PR contra cualquier rama.

### 2. Contenedor temporal

El pipeline usa:

```yaml
image: node:22-bullseye
```

Bitbucket crea un contenedor Docker nuevo para cada step. Ese contenedor:

- No es permanente.
- Se destruye cuando termina el step.
- No conserva archivos salvo artifacts y caches declarados.
- Clona el repo en una carpeta temporal.
- Ejecuta los comandos del bloque `script`.

Por eso Bob Shell se instala en cada corrida, salvo lo que se pueda acelerar con cache.

### 3. Instalacion de Bob Shell

`scripts/install-bob-shell.sh`:

1. Verifica que Node.js sea version 20 o superior.
2. Descarga el instalador oficial:
   `https://bob.ibm.com/download/bobshell.sh`
3. Lo ejecuta con `--pm npm` para evitar prompts interactivos.
4. Valida que el comando `bob` exista.

El flag `--pm npm` es importante porque un pipeline no tiene `/dev/tty`; no puede responder menus interactivos.

### 4. Carga de reglas

`scripts/bobshell-pr-review.sh` busca reglas en este orden:

1. `BOBSHELL_RULES_LOCAL_PATH`, si se definio.
2. `bobshell-rules/` dentro del repo actual.
3. `BOBSHELL_RULES_REPO_URL`, si se definio.

Para el POC actual se usa `bobshell-rules/` local. Para produccion se puede usar otro repo privado con reglas compartidas.

Si las reglas estan en otro repo, no se necesita la REST API de Bitbucket para leerlas. Se usa `git clone`. La autenticacion dependera de la URL:

| Tipo de URL | Como autentica |
|---|---|
| `git@bitbucket.org:workspace/rules.git` | SSH key configurada en Bitbucket |
| `https://x-token-auth:<token>@bitbucket.org/workspace/rules.git` | Repository access token |

### 5. Obtencion del diff

Antes se intentaba llamar a la REST API:

```text
GET /2.0/repositories/{workspace}/{repo}/pullrequests/{id}/diff
```

Eso fallo con 401 por autenticacion. Para el pipeline no hace falta usar API porque el repo ya esta clonado. Ahora el script detecta que esta dentro de Bitbucket Pipelines y usa `git diff` local.

Ventaja:

- No depende de token para leer el diff.
- Evita problemas con IBM SSO y API keys.
- Es mas rapido y simple.

### 6. Construccion del prompt

El script arma `.bobshell/prompt.md` con:

1. Contexto del PR.
2. Contrato de salida desde `bobshell-rules/prompts/review-pr.md`.
3. Todas las reglas `*.md` dentro de `bobshell-rules/rules/`.
4. El diff del PR.

Ese prompt se manda a Bob Shell.

### 7. Ejecucion de Bob

`scripts/bob-ci-runner.sh` recibe el prompt por stdin y ejecuta:

```bash
cat "$PROMPT_TMP" | bob --accept-license --auth-method api-key
```

Bob usa `BOBSHELL_API_KEY` para autenticarse sin navegador.

### 8. Artifact

El output de Bob se guarda como:

```text
bobshell-review.md
```

Y el pipeline declara:

```yaml
artifacts:
  - bobshell-review.md
  - .bobshell/**
```

Los artifacts existen solo dentro de Bitbucket Pipelines. No aparecen en el codigo del repo ni en tu carpeta local a menos que los descargues manualmente. Bitbucket los guarda asociados a esa corrida del pipeline.

### 9. Comentario en el PR

Para comentar en el PR, el script llama a la REST API de Bitbucket:

```text
POST /2.0/repositories/{workspace}/{repo}/pullrequests/{id}/comments
```

Usa:

```text
Authorization: Bearer $BOBSHELL_BB_TOKEN
```

Ese token debe ser un **Repository Access Token** con permiso de escritura sobre Pull requests.

## Como funciona `/bob`

Bitbucket no dispara pipelines automaticamente por cada comentario nuevo en un PR.

Por eso el POC incluye `scripts/bobshell-poll-comments.sh`, que esta pensado para ejecutarse como pipeline manual o programado:

```yaml
custom:
  bob-poll-comments:
```

Ese script:

1. Lista PRs abiertos.
2. Lee comentarios recientes.
3. Busca comentarios que empiecen con `/bob`.
4. Si encuentra `/bob`, puede disparar un review.
5. Si encuentra `/bob <pregunta>`, arma un prompt Q&A y responde con Bob.
6. Publica una respuesta con un marcador oculto para no procesar dos veces el mismo comentario.

Ejemplos de comentarios:

```text
/bob
```

Pide un review general.

```text
/bob explica los riesgos de seguridad de este PR
```

Pide una respuesta especifica sobre el PR.

```text
/bob resume este cambio para un reviewer funcional
```

Pide resumen en lenguaje natural.

## Por que en GitHub puede sentirse mas inmediato

GitHub Actions tiene eventos nativos como:

```yaml
on:
  issue_comment:
    types: [created]
```

Eso permite ejecutar un workflow casi al instante cuando alguien comenta `/bob`.

Ademas GitHub inyecta `GITHUB_TOKEN`, que normalmente puede leer PRs y escribir comentarios sin crear un token extra.

En Bitbucket Pipelines, el trigger nativo por comentario no esta disponible igual. Por eso hay tres opciones:

| Opcion | Velocidad | Complejidad | Comentario |
|---|---:|---:|---|
| Scheduled pipeline cada 30 min | Baja | Baja | Simple, pero no inmediato. |
| Scheduled pipeline cada 5-10 min | Media | Baja | Mas rapido, consume mas minutos. |
| Webhook externo | Alta | Media/Alta | Casi inmediato; requiere un servicio externo que reciba el webhook y dispare una accion. |
| Bitbucket app / Forge / Connect | Alta | Alta | Mas profesional, pero mas trabajo. |

Para un POC, el polling programado es suficiente. Para produccion, lo ideal seria webhook externo o app.

## Como funcionan pipelines y deploys

### Bitbucket Pipelines

Bitbucket Pipelines ejecuta pasos dentro de contenedores Docker. Cada step define:

- Imagen base (`image`).
- Comandos (`script`).
- Artifacts.
- Caches.
- Variables.
- Opcionalmente deployment environment.

Ejemplo conceptual:

```yaml
pipelines:
  branches:
    master:
      - step:
          name: Deploy production
          deployment: production
          script:
            - npm ci
            - npm test
            - ./deploy.sh
```

El deploy no es magico: es un script que corre dentro del contenedor. Puede usar credenciales seguras para llamar a AWS, Azure, IBM Cloud, Kubernetes, OpenShift, etc.

### GitHub Actions

GitHub Actions funciona parecido:

- Crea un runner temporal.
- Hace checkout del codigo.
- Ejecuta steps.
- Usa secrets.
- Sube artifacts.
- Puede comentar PRs con API.

Diferencias importantes:

| Tema | Bitbucket Pipelines | GitHub Actions |
|---|---|---|
| Unidad de ejecucion | Docker container por step | Runner VM/container |
| Token automatico para API | Mas limitado; aqui usamos repo access token | `GITHUB_TOKEN` integrado |
| Trigger por comentario | No directo en Pipelines | `issue_comment` nativo |
| Artifacts | Asociados a pipeline run | Asociados a workflow run |
| Deployments | `deployment: environment` | `environment:` |

## Estructura actual de la carpeta

### Archivos raiz

| Archivo/carpeta | Uso |
|---|---|
| `.gitignore` | Evita subir archivos generados/locales. |
| `bitbucket-pipelines.yml` | Define el pipeline automatico de PR review y pipelines manuales. |
| `bobshell-rules/` | Reglas y prompt que Bob usa para revisar PRs. Es parte central del POC. |
| `scripts/` | Scripts ejecutados por el pipeline. Es parte central del POC. |
| `tests/` | Pruebas y fixtures locales para validar el POC sin depender siempre de Bitbucket. |
| `docs/` | Documentacion del POC. |
| `archive/` | Material historico o no necesario para ejecutar el POC actual. |

### `scripts/`

| Archivo | Uso |
|---|---|
| `install-bob-shell.sh` | Instala Bob Shell en el contenedor del pipeline. |
| `bob-ci-runner.sh` | Ejecuta Bob en modo CI usando `BOBSHELL_API_KEY`. |
| `bobshell-pr-review.sh` | Orquesta el review de PR: reglas, diff, prompt, Bob, artifact y comentario. |
| `bobshell-poll-comments.sh` | Escanea comentarios `/bob` en PRs abiertos y responde. Se usa con pipeline manual/programado. |

### `bobshell-rules/`

| Archivo | Uso |
|---|---|
| `README.md` | Explica el paquete de reglas. |
| `prompts/review-pr.md` | Define como debe responder Bob en reviews. |
| `rules/architecture.md` | Reglas de arquitectura. |
| `rules/design-patterns.md` | Reglas de patrones de diseno. |
| `rules/pr-standards.md` | Reglas de estandar de pull request. |
| `rules/security.md` | Reglas de seguridad. |

### `tests/`

| Archivo | Uso |
|---|---|
| `fixtures/sample.diff` | Diff de ejemplo para pruebas locales. |
| `fixtures/test-security-trigger.py` | Archivo intencionalmente inseguro para validar que Bob detecta problemas. |
| `mock-bobshell.sh` | Simula Bob para pruebas locales sin llamar al servicio real. |
| `run-local-poc-test.sh` | Ejecuta una prueba local del flujo. |

### `archive/`

| Carpeta | Uso |
|---|---|
| `archive/not-used-for-poc/` | Archivos historicos o de ideas previas que no son necesarios para el POC operativo. |
| `archive/pipeline-logs/` | Logs descargados localmente desde Bitbucket. Sirven para diagnostico, pero no para ejecutar el POC. |

## Que se movio a archive

Se movio el log local descargado:

```text
pipelineLog-{a8312f72-2e20-4cbf-b6dc-1a0a833d3339}.txt
```

a:

```text
archive/pipeline-logs/pipelineLog-{a8312f72-2e20-4cbf-b6dc-1a0a833d3339}.txt
```

No se movieron scripts, reglas, tests ni `bitbucket-pipelines.yml` porque todos forman parte del POC o de su validacion.

## Recomendacion para la siguiente etapa

Para POC:

- Mantener reglas locales en `bobshell-rules/`.
- Mantener comentarios automaticos con `BOBSHELL_BB_TOKEN`.
- Usar `/bob` mediante pipeline manual o scheduled pipeline.

Para produccion:

- Mover `bobshell-rules/` a un repo compartido.
- Configurar `BOBSHELL_RULES_REPO_URL`.
- Implementar webhook externo para responder `/bob` casi al instante.
- Agregar reglas de merge checks para requerir pipeline verde antes de merge.
- Definir `BOBSHELL_FAIL_ON=high` o `medium` si quieren bloquear PRs con hallazgos serios.

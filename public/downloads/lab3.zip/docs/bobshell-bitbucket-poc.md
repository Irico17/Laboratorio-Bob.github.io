# IBM Bob Shell + Bitbucket Pipelines

This project integrates IBM Bob Shell CLI with Bitbucket Pipelines for automated code review, issue fixing, PR labeling, and deep analysis — achieving feature parity with the GitHub Actions version.

## All Pipelines

| Pipeline | Trigger | Script | Purpose |
| --- | --- | --- | --- |
| `pull-requests: '**':` | Auto on PR open/update | `bobshell-pr-review.sh` | Full PR review with rules |
| `default:` | Auto on push (no PR) | `bobshell-commit-review.sh` | Review latest commit |
| `custom: bob-review` | Manual / `/bob` | `bobshell-pr-review.sh` | On-demand PR review |
| `custom: bob-poll-comments` | Scheduled (30–60 min) | `bobshell-poll-comments.sh` | Scan PRs for `/bob` commands |
| `custom: bob-fix-review` | Manual / `/bob fix` | `bobshell-fix-review.sh` | Fix PR review comments |
| `custom: bob-fix-issue` | Manual | `bobshell-fix-issue.sh` | Fix Bitbucket issue → create PR |
| `custom: bob-deep-review` | Manual / `/bob deep-review` | `bobshell-deep-review.sh` | Deep branch analysis |
| `custom: bob-label-pr` | Manual / `/bob label` | `bobshell-label-pr.sh` | Auto-categorize PR |
| `custom: bob-label-issue` | Manual | `bobshell-label-issue.sh` | Auto-classify issue |

## Files

| Path | Purpose |
| --- | --- |
| `bitbucket-pipelines.yml` | All pipeline definitions (auto + custom). |
| `scripts/install-bob-shell.sh` | Installs Node.js 22 and Bob Shell in the pipeline container. |
| `scripts/bob-ci-runner.sh` | CI wrapper: reads stdin, runs Bob, writes stdout. |
| `scripts/bobshell-pr-review.sh` | Builds review prompt from rules + PR diff, runs Bob, posts comment. |
| `scripts/bobshell-commit-review.sh` | Reviews the latest commit diff using Bob. |
| `scripts/bobshell-poll-comments.sh` | Polls open PRs for `/bob` commands and dispatches pipelines. |
| `scripts/bobshell-fix-review.sh` | Reads PR review comments, runs Bob to fix code, commits and pushes. |
| `scripts/bobshell-fix-issue.sh` | Fetches Bitbucket issue, runs Bob to fix, creates PR. |
| `scripts/bobshell-deep-review.sh` | Comprehensive analysis of all source files in a branch. |
| `scripts/bobshell-label-pr.sh` | Analyzes PR and posts category suggestions as a comment. |
| `scripts/bobshell-label-issue.sh` | Classifies a Bitbucket issue (kind, priority, component). |
| `bobshell-rules/` | Review rules and prompt contract. |
| `tests/` | Local smoke tests with mock Bob command. |
| `docs/` | Documentation including GitHub vs Bitbucket mapping. |

## Required Bitbucket variables

Set these in **Repository settings → Repository variables**.

| Variable | Required | Notes |
| --- | --- | --- |
| `BOBSHELL_API_KEY` | Yes | Bob API key from `bob.ibm.com`, created with Scope = `Inference`. Mark as secured. |
| `BITBUCKET_USERNAME` | Yes | Atlassian account email or Bitbucket username used for Basic Auth. |
| `BITBUCKET_API_KEY` | Yes | Atlassian API key with Bitbucket access. Mark as secured. |
| `BITBUCKET_APY_KEY` | Supported alias | The scripts accept this typo as an alias if you already configured it. |
| `BOBSHELL_COMMAND` | Optional | Defaults to `bash scripts/bob-ci-runner.sh` in the pipeline. |

Atlassian's current API-key docs say API keys are used with Basic Auth as:

```bash
curl -u user@example.com:<api-key> <url>
```

The scripts use the new API-key style and also accept your existing `BITBUCKET_APY_KEY` variable name.

## Optional variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `BOBSHELL_RULES_REPO_URL` | unset | Git URL for an external rules repository. If unset, local `bobshell-rules/` is used. |
| `BOBSHELL_RULES_REF` | `main` | Branch, tag, or commit for the external rules repo. |
| `BOBSHELL_OUTPUT_MODE` | `both` | `artifact`, `comment`, or `both`. |
| `BOBSHELL_FAIL_ON` | `never` | `never`, `critical`, `high`, `medium`, or `low`. |
| `BOBSHELL_REQUIRE_COMMAND` | `false` | If `true`, fail when Bob is unavailable instead of producing dry-run output. |
| `BOBSHELL_POLL_LOOKBACK` | `90` | Minutes to look back for unhandled `/bob` commands. |

## How the PR review works

1. A PR is opened or updated.
2. Bitbucket runs the `pull-requests` pipeline.
3. The pipeline runs `scripts/install-bob-shell.sh`.
4. `scripts/bobshell-pr-review.sh` loads rules from `bobshell-rules/` or `BOBSHELL_RULES_REPO_URL`.
5. The script fetches the PR diff through the Bitbucket API using `BITBUCKET_USERNAME` + `BITBUCKET_API_KEY`.
6. It writes `.bobshell/prompt.md`.
7. It runs:

```bash
bash scripts/bob-ci-runner.sh < .bobshell/prompt.md > bobshell-review.md
```

8. `bob-ci-runner.sh` calls Bob:

```bash
cat prompt.md | bob --accept-license --auth-method api-key
```

9. The review is saved as `bobshell-review.md` and posted back to the PR as a comment.

## How `/bob` comments work

Bitbucket Cloud does not trigger Pipelines directly from PR comments like GitHub Actions can. The POC uses scheduled polling instead.

Configure a schedule in **Pipelines → Schedules** for the custom pipeline `bob-poll-comments` every 30-60 minutes.

### Bare `/bob`

Example PR comment:

```text
/bob
```

Flow:

1. `bob-poll-comments` scans open PR comments.
2. It finds the latest unacknowledged `/bob`.
3. It posts an acknowledgment comment containing `<!-- bobshell-ack -->`.
4. It triggers the custom `bob-review` pipeline with `PR_ID`.
5. `bob-review` performs the same full Bob Shell review as the automatic PR pipeline.

### `/bob <message>`

Example PR comments:

```text
/bob resume este PR en 5 puntos
/bob hay riesgos de seguridad?
/bob explica por que se cambio este archivo
```

Flow:

1. `bob-poll-comments` scans open PR comments.
2. It detects text after `/bob`.
3. It fetches the PR diff.
4. It builds a Q&A prompt containing the user's question and the diff.
5. It runs Bob through `BOBSHELL_COMMAND`.
6. It posts Bob's Markdown answer directly in the PR thread with the ack marker.

The hidden ack marker prevents the same command from running repeatedly.

## Local smoke test

Run from the repository root:

```bash
bash tests/run-local-poc-test.sh
```

Expected output:

```text
Local BobShell POC test passed.
```

The smoke test uses `tests/mock-bobshell.sh`, not the real Bob API.

---

## How to push and trigger the first real pipeline test

### 1. Push both branches

The test branch `test/poc-trigger-pr` contains `tests/fixtures/test-security-trigger.py` — a file with intentionally hardcoded fake credentials and SQL injection vulnerabilities to verify Bob detects them.

```bash
# Replace with your Atlassian email and API key
BITBUCKET_USER=your-email@domain.com
BITBUCKET_KEY=your-atlassian-api-key

git remote set-url origin https://${BITBUCKET_USER}:${BITBUCKET_KEY}@bitbucket.org/bob-shell-integration/bob-shell-integration.git

git push origin master
git push origin test/poc-trigger-pr
```

### 2. Create a PR in Bitbucket

1. Go to `https://bitbucket.org/bob-shell-integration/bob-shell-integration/pull-requests`
2. Click **Create pull request**
3. Source: `test/poc-trigger-pr` → Destination: `master`
4. Create the PR

### 3. What happens automatically

- Bitbucket detects the PR and starts the **BobShell PR Review** pipeline (configured under `pull-requests: '**':`).
- The pipeline container:
  1. Runs `install-bob-shell.sh` (installs Node.js 22 + Bob CLI in the container)
  2. Runs `bobshell-pr-review.sh` which fetches the diff via Bitbucket API
  3. Builds a prompt combining your `bobshell-rules/security.md` + the diff
  4. Feeds the prompt to `bob --accept-license --auth-method api-key`
  5. Posts Bob's Markdown review as a PR comment
- After the run, check the PR comments. Bob should flag the fake API keys and SQL injection.

### 4. Configure the schedule for `/bob` polling

To enable comment polling:
1. In Bitbucket: **Pipelines → Schedules → Add schedule**
2. Select pipeline: `bob-poll-comments`
3. Set interval: every 30 or 60 minutes
4. After that, any PR comment starting with `/bob` triggers Bob within 30-60 minutes.

---

## GitHub vs Bitbucket: why /bob is instant on GitHub but polled here

### GitHub Actions (instant)

GitHub has a built-in webhook event called `issue_comment`. When someone comments on a PR, GitHub:

1. Fires the `issue_comment.created` event **internally** inside GitHub's infrastructure
2. Your workflow file says `on: issue_comment` → the workflow starts **immediately**
3. The bot reads the comment, calls your API, and posts back within seconds

Everything runs inside GitHub itself. No external server needed.

### Bitbucket Pipelines (polling required)

Bitbucket Cloud does have comment webhooks, but they work differently:

- When someone comments, Bitbucket fires an HTTP POST to an **external URL you provide** (your server)
- That external server has to receive the webhook, then call the Bitbucket Pipelines API to trigger a pipeline
- This means you need a **always-on server hosted somewhere** (AWS Lambda, Railway, Render, etc.)

For the POC, we use **scheduled polling** instead to avoid hosting external infrastructure:

```
Every 30 min:
  Bitbucket wakes up a container
  → script scans all open PRs for /bob comments
  → if found and not yet acknowledged, calls Bob and posts answer
  → container shuts down
```

### Making it instant (future upgrade)

If you want instant `/bob` responses, you need one extra component:

```
PR comment posted
  → Bitbucket fires webhook → your webhook relay (Lambda/Fly.io/Railway)
  → relay calls Bitbucket Pipelines API: POST /2.0/repositories/{ws}/{repo}/pipelines
  → pipeline runs bob-poll-comments
  → Bob responds in 2-5 minutes (install time included)
```

The relay is just ~20 lines of Python/Node that:
1. Validates the Bitbucket webhook signature
2. Checks if the comment starts with `/bob`
3. Calls the Bitbucket Pipelines API to trigger `bob-poll-comments`

This is a straightforward future upgrade once the POC is validated.

---

## How Bitbucket Pipelines work — where does the code run?

Bitbucket Pipelines run in **Docker containers on Atlassian-managed cloud infrastructure** (similar to GitHub Actions hosted runners):

| What | How |
|---|---|
| Container image | `atlassian/default-image:4` (Debian-based) |
| Who manages the VMs | Atlassian — no setup needed on your end |
| Persistence | None — each step runs in a fresh, isolated container |
| Duration limit | 120 minutes per step (free tier: 50 build minutes/month) |
| Scheduled pipelines | Atlassian's scheduler wakes a container at the configured interval |

**Key implication for Bob Shell:** Because each step starts fresh, Node.js must be installed in the same step that uses Bob. `install-bob-shell.sh` handles this — it installs Node.js 22 (upgrading from the default v18) and Bob Shell before any script calls `bob`.

The `node` cache defined in `bitbucket-pipelines.yml` speeds this up — Bitbucket re-uses the node_modules cache between runs so Bob doesn't need to be re-downloaded every time.

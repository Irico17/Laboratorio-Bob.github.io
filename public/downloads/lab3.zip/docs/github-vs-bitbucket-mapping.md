# GitHub Actions vs Bitbucket Pipelines — Feature Mapping

This document maps the BobLab (GitHub) workflows to BobBitbucket (Bitbucket) equivalents.

## Workflow Mapping

| # | GitHub Workflow | Bitbucket Pipeline | Trigger | Script |
|---|---|---|---|---|
| 1 | `review-pr-with-skills.yml` | `pull-requests: '**':` | Auto on PR open/update | `bobshell-pr-review.sh` |
| 2 | `review-commit-on-push.yml` | `default:` | Auto on push (fallback) | `bobshell-commit-review.sh` |
| 3 | `pr-review-lab.yml` | `custom: bob-review:` | Manual | `bobshell-pr-review.sh` |
| 4 | `fix-pr-reviews-with-bob.yml` | `custom: bob-fix-review:` | Manual or `/bob fix` | `bobshell-fix-review.sh` |
| 5 | `fix-pr-reviews-with-bob-trigger.yml` | *(not needed)* | N/A | Bitbucket doesn't need trigger chains |
| 6 | `fix-issues-with-bob.yml` | `custom: bob-fix-issue:` | Manual | `bobshell-fix-issue.sh` |
| 7 | `label-new-prs.yml` | `custom: bob-label-pr:` | Manual or `/bob label` | `bobshell-label-pr.sh` |
| 8 | `label-new-prs-trigger.yml` | *(not needed)* | N/A | Bitbucket doesn't need trigger chains |
| 9 | `label-new-issues.yml` | `custom: bob-label-issue:` | Manual | `bobshell-label-issue.sh` |
| 10 | `deep-branch-review.yml` | `custom: bob-deep-review:` | Manual or `/bob deep-review` | `bobshell-deep-review.sh` |

## `/bob` Comment Commands

| Command | GitHub | Bitbucket |
|---|---|---|
| `/bob` | `issue_comment` → instant | Polling (30–60 min) → `bob-review` |
| `/bob fix` | N/A (uses label trigger) | Polling → `bob-fix-review` |
| `/bob label` | N/A (auto on PR open) | Polling → `bob-label-pr` |
| `/bob deep-review` | `workflow_dispatch` (manual) | Polling → `bob-deep-review` |
| `/bob <question>` | `issue_comment` → instant | Polling → inline answer |

## Platform Differences

### Triggers

| Capability | GitHub | Bitbucket |
|---|---|---|
| PR open/update | `on: pull_request` | `pipelines: pull-requests:` |
| Push | `on: push` | `pipelines: default:` (fallback) or `branches:` (specific) |
| Comment | `on: issue_comment` (instant) | ❌ No native → scheduled polling |
| Label added | `on: issues: [labeled]` | ❌ No native → manual or polling |
| Manual | `on: workflow_dispatch` | `pipelines: custom:` |
| Scheduled | `on: schedule` | Pipelines Schedules UI |

### Authentication

| Feature | GitHub | Bitbucket |
|---|---|---|
| Auto token | `GITHUB_TOKEN` injected | ❌ Must create `BOBSHELL_BB_TOKEN` |
| Fork safety | `workflow_run` chain pattern | Not needed (secrets always available) |
| API style | `gh api ...` | `curl` with Bearer token |

### Labels

| Feature | GitHub | Bitbucket |
|---|---|---|
| PR labels | Native label system | ❌ No PR labels — uses comment-based categories |
| Issue labels | Arbitrary labels | Kind + Priority + Component (fixed fields) |
| Auto-labeling | Apply via API | Update issue fields or post comment |

### Artifacts

| Feature | GitHub | Bitbucket |
|---|---|---|
| Upload | `actions/upload-artifact` | `artifacts:` in YAML |
| Download | `actions/download-artifact` | Pipeline Artifacts UI |
| Cross-job | Via artifact download | Via `artifacts` keyword |

## Variable Mapping

| GitHub Secret | Bitbucket Variable | Purpose |
|---|---|---|
| `BOBSHELL_API_KEY` | `BOBSHELL_API_KEY` | Bob Shell API key |
| `GITHUB_TOKEN` | `BOBSHELL_BB_TOKEN` | Repository access token |
| `GH_PAT` | `BOBSHELL_BB_TOKEN` | Write access to PRs/issues |
| — | `BITBUCKET_USERNAME` | Auth user (Basic Auth fallback) |
| — | `BITBUCKET_API_KEY` | Auth secret (Basic Auth fallback) |

## Architecture Differences

### GitHub: Trigger Chain Pattern

GitHub uses a two-workflow pattern for fork PR security:

```
PR opened → label-new-prs-trigger.yml (has PR context, no secrets)
  → uploads pr-context artifact
  → workflow_run event
    → label-new-prs.yml (has secrets, downloads context)
```

### Bitbucket: Direct Access

Bitbucket repository variables are available to all pipeline runs, including fork PRs. No trigger chain needed:

```
PR opened → pull-requests pipeline (has context + secrets)
```

### Bitbucket: Polling Pattern

Since Bitbucket doesn't have native comment triggers:

```
Every 30 min → bob-poll-comments scheduled pipeline
  → scans all open PRs for /bob commands
  → triggers appropriate custom pipeline via API
```

Future upgrade: Replace polling with a webhook relay (AWS Lambda, etc.) for near-instant response.

#!/usr/bin/env bash
# bob-ci-runner.sh
#
# CI wrapper for IBM Bob Shell.
# Reads a prompt from stdin, runs bob non-interactively, writes output to stdout.
#
# This script bridges the BOBSHELL_COMMAND contract (stdin → stdout) with Bob's
# `-p` flag interface, while also handling:
#   • API-key authentication (no browser needed in CI)
#   • One-time license acceptance (required before first non-interactive run)
#
# Required:
#   BOBSHELL_API_KEY  – API key from bob.ibm.com (create at bob.ibm.com → API keys,
#                       set Scope = Inference). Add as a *secured* Bitbucket variable.
#
# Usage:
#   Set in Bitbucket repository variables:
#     BOBSHELL_COMMAND=bash scripts/bob-ci-runner.sh
#     BOBSHELL_API_KEY=<your-api-key>
#
# Install Bob Shell first (run this once before using):
#   Visit bob.ibm.com/download → follow install instructions for your OS.
#   Requires Node.js >= 22.15.0.
#   Verify: bob --version

set -Eeuo pipefail

die() { printf '[bob-ci] ERROR: %s\n' "$*" >&2; exit 1; }
log() { printf '[bob-ci] %s\n' "$*" >&2; }

command -v bob >/dev/null 2>&1 \
  || die "bob not found in PATH. Install from bob.ibm.com/download (requires Node.js 22+)"

: "${BOBSHELL_API_KEY:?BOBSHELL_API_KEY must be set. Get it from bob.ibm.com → API keys (Scope = Inference)}"

# Read full prompt from stdin into a temp file
PROMPT_TMP=$(mktemp)
trap 'rm -f "$PROMPT_TMP"' EXIT

cat > "$PROMPT_TMP"
[ -s "$PROMPT_TMP" ] || die "Empty prompt received on stdin"

# Force Spanish responses for all pipeline reviews and comments
printf "\n\nIMPORTANT: Write your response, comments, review, and all output strictly in Spanish (español). Do not use English.\n" >> "$PROMPT_TMP"

log "Prompt size: $(wc -c < "$PROMPT_TMP") bytes"
log "Running IBM Bob Shell (non-interactive, API key auth)"

# --accept-license    Accepts the IBM Bob license silently (safe to pass on every run)
# --auth-method api-key  Uses BOBSHELL_API_KEY env var instead of browser IBMid login
#
# Per bob.ibm.com/docs: "For multi-line prompts, save them to a file and pipe to Bob Shell"
#   cat prompt.txt | bob
# This avoids shell argument-length limits on large PR diffs.

RAW_TMP=$(mktemp)
trap 'rm -f "$PROMPT_TMP" "$RAW_TMP"' EXIT

cat "$PROMPT_TMP" | bob --accept-license --auth-method api-key > "$RAW_TMP"

# ── Strip Bob's internal thinking blocks ─────────────────────────────────
# Bob Shell may prepend a <thinking>...</thinking> block and a ---output---
# separator before the actual review. We strip all of that so only the
# clean Markdown review reaches stdout.
#
# Patterns removed:
#   1. Everything between <thinking> and </thinking> (multi-line)
#   2. Lines matching [using tool ...] cost metadata
#   3. The ---output--- separator line
#   4. Leading blank lines after stripping

if command -v python3 >/dev/null 2>&1; then
  python3 - "$RAW_TMP" <<'PYEOF'
import re, sys
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()

idx = text.rfind('[using tool attempt_completion')
if idx != -1:
    m = re.search(r'---output---\s*', text[idx:])
    if m:
        text = text[idx + m.end():]
    else:
        text = text[idx:]
        text = re.sub(r'^\[using tool attempt_completion[^\]]*\]\s*', '', text)
else:
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
    text = re.sub(r'\[using tool[^\]]*\]', '', text)
    text = re.sub(r'---output---', '', text)
    text = re.sub(r'Read lines \d+-\d+ of \d+ from \S+', '', text)

text = text.strip() + '\n'
sys.stdout.write(text)
PYEOF
else
  # Fallback: simple sed-based stripping
  sed -e 's/\[using tool.*\]//g' -e 's/---output---//g' "$RAW_TMP" | sed -e '/./,$!d'
fi


#!/usr/bin/env bash
# bobshell-commit-review.sh
#
# Reviews the latest commit pushed to a branch using Bob Shell with custom rules.
# Equivalent of the GitHub Actions "review-commit-on-push.yml" workflow.
#
# Produces:
#   bobshell-commit-review.md  – artifact with the review
#   .bobshell/commit-prompt.md – the prompt sent to Bob
#
# Environment (set automatically by Bitbucket Pipelines):
#   BITBUCKET_WORKSPACE, BITBUCKET_REPO_SLUG, BITBUCKET_BRANCH,
#   BITBUCKET_COMMIT, BITBUCKET_BUILD_NUMBER
#
# Required:
#   BOBSHELL_API_KEY – Bob API key (Scope = Inference)
#
# Optional:
#   BOBSHELL_COMMAND           – override the Bob execution command
#   BOBSHELL_RULES_LOCAL_PATH  – path to rules directory
#   BOBSHELL_RULES_REPO_URL    – Git URL for external rules repo
#   BOBSHELL_RULES_REF         – branch/tag for external rules (default: main)
#   BOBSHELL_COMMIT_REVIEW_FILE – output file (default: bobshell-commit-review.md)

set -Eeuo pipefail

log() { printf '[bobshell-commit] %s\n' "$*"; }
die() { printf '[bobshell-commit] ERROR: %s\n' "$*" >&2; exit 1; }

WORK_DIR="${BOBSHELL_WORK_DIR:-.bobshell}"
RULES_DIR="$WORK_DIR/rules-repo"
PROMPT_FILE="$WORK_DIR/commit-prompt.md"
DIFF_FILE="$WORK_DIR/commit.diff"
REVIEW_FILE="${BOBSHELL_COMMIT_REVIEW_FILE:-bobshell-commit-review.md}"
RULES_REF="${BOBSHELL_RULES_REF:-main}"

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"
}

# ── Rules loading (shared logic with bobshell-pr-review.sh) ───────────────────

checkout_rules() {
  rm -rf "$RULES_DIR"
  mkdir -p "$WORK_DIR"

  if [ -n "${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}" ]; then
    local custom_path="${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}"
    [ -d "$custom_path" ] || die "Skills path does not exist: $custom_path"
    log "Copying skills from $custom_path"
    cp -R "$custom_path" "$RULES_DIR"
    return
  fi

  local repo_skills="${BITBUCKET_CLONE_DIR:-.}/.bob/skills"
  if [ -d "$repo_skills" ]; then
    log "Using skills from $repo_skills"
    mkdir -p "$RULES_DIR"
    cp -R "$repo_skills/." "$RULES_DIR/"
    return
  fi

  local repo_rules="${BITBUCKET_CLONE_DIR:-.}/bobshell-rules"
  if [ -d "$repo_rules" ]; then
    log "Using legacy rules from $repo_rules (consider migrating to .bob/skills/)"
    mkdir -p "$RULES_DIR"
    cp -R "$repo_rules/." "$RULES_DIR/"
    return
  fi

  [ -n "${BOBSHELL_RULES_REPO_URL:-}" ] || die "No skills found. Add .bob/skills/ to the repo or set BOBSHELL_SKILLS_PATH"
  log "Cloning rules repository ref ${RULES_REF}"
  git clone --quiet --depth 1 --branch "$RULES_REF" "$BOBSHELL_RULES_REPO_URL" "$RULES_DIR"
}

append_rules() {
  local skill_files
  skill_files=$(find "$RULES_DIR" -name 'SKILL.md' -type f 2>/dev/null | sort)

  if [ -n "$skill_files" ]; then
    echo "$skill_files" | while IFS= read -r file; do
      local skill_name
      skill_name=$(basename "$(dirname "$file")")
      printf '\n### Skill: %s\n\n' "$skill_name"
      python3 -c "
import sys
text = open(sys.argv[1], encoding='utf-8').read()
if text.startswith('---'):
    end = text.find('---', 3)
    if end != -1:
        text = text[end+3:].lstrip('\\n')
print(text)
" "$file"
      printf '\n'
    done
    return
  fi

  local rules_path="$RULES_DIR/rules"
  if [ -d "$rules_path" ]; then
    find "$rules_path" -type f -name '*.md' | sort | while IFS= read -r file; do
      printf '\n### %s\n\n' "$(basename "$file")"
      cat "$file"
      printf '\n'
    done
    return
  fi

  log "WARNING: No SKILL.md files or rules/ directory found in $RULES_DIR"
}

# ── Commit diff ───────────────────────────────────────────────────────────────

fetch_commit_diff() {
  log "Getting commit diff (HEAD~1..HEAD)"
  if git rev-parse --verify HEAD~1 >/dev/null 2>&1; then
    git diff HEAD~1 HEAD | head -c 100000 > "$DIFF_FILE"
  else
    # First commit in repo
    git diff --cached HEAD | head -c 100000 > "$DIFF_FILE" 2>/dev/null || git show --stat HEAD > "$DIFF_FILE"
  fi
}

# ── Build prompt ──────────────────────────────────────────────────────────────

build_prompt() {
  [ -f "$DIFF_FILE" ] || die "Diff file was not created: $DIFF_FILE"

  local commit_msg commit_author commit_sha changed_files
  commit_msg=$(git log -1 --pretty=%B 2>/dev/null || printf 'unknown')
  commit_author=$(git log -1 --pretty=%an 2>/dev/null || printf 'unknown')
  commit_sha=$(git log -1 --pretty=%H 2>/dev/null || printf 'unknown')
  changed_files=$(git diff --name-only HEAD~1 HEAD 2>/dev/null | tr '\n' ', ' || printf 'unknown')

  {
    printf '# BobShell Commit Review Request\n\n'
    printf 'You are BobShell running inside Bitbucket Pipelines. Review the latest commit using the rules below.\n\n'
    printf '## Commit Information\n\n'
    printf -- '- Workspace: %s\n' "${BITBUCKET_WORKSPACE:-local}"
    printf -- '- Repository: %s\n' "${BITBUCKET_REPO_SLUG:-local}"
    printf -- '- Branch: %s\n' "${BITBUCKET_BRANCH:-unknown}"
    printf -- '- Commit: %s\n' "$commit_sha"
    printf -- '- Author: %s\n' "$commit_author"
    printf -- '- Message: %s\n' "$commit_msg"
    printf -- '- Changed files: %s\n' "$changed_files"
    printf '\n## Skills & Rules\n'
    append_rules
    printf '\n## Commit Diff\n\n```diff\n'
    cat "$DIFF_FILE"
    printf '\n```\n'
    printf '\n## Instructions\n\n'
    printf '1. Analyze the code changes in this commit\n'
    printf '2. Apply ALL review rules from the rules section above\n'
    printf '3. Identify issues by severity (CRITICAL / HIGH / MEDIUM / LOW)\n'
    printf '4. Provide specific recommendations with file and line references\n'
    printf '5. Keep feedback concise and actionable\n'
  } > "$PROMPT_FILE"

  log "Prompt written to $PROMPT_FILE"
}

# ── Strip Bob's thinking blocks ───────────────────────────────────────────────

strip_bob_thinking() {
  local file="$1"
  [ -f "$file" ] || return 0
  if command -v python3 >/dev/null 2>&1; then
    local tmp; tmp=$(mktemp)
    python3 - "$file" > "$tmp" <<'PYEOF'
import re, sys
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()

idx = text.rfind('[using tool attempt_completion')
if idx != -1:
    m = re.search(r'---output---\s*', text[idx:])
    if m:
        text = text[idx + m.end():]
    else:
        text = text[idx:]
        text = re.sub(r'^\[using tool attempt_completion[^\]]*\]\s*', '', text)
else:
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
    text = re.sub(r'\[using tool[^\]]*\]', '', text)
    text = re.sub(r'---output---', '', text)
    text = re.sub(r'Read lines \d+-\d+ of \d+ from \S+', '', text)

text = text.strip() + '\n'
sys.stdout.write(text)
PYEOF
    mv "$tmp" "$file"
  else
    local tmp; tmp=$(mktemp)
    sed -e 's/\[using tool.*\]//g' -e 's/---output---//g' "$file" > "$tmp"
    mv "$tmp" "$file"
  fi
}

# ── Run BobShell ──────────────────────────────────────────────────────────────

run_bobshell() {
  if [ -n "${BOBSHELL_COMMAND:-}" ]; then
    log "Running BobShell command: $BOBSHELL_COMMAND"
    sh -c "$BOBSHELL_COMMAND" < "$PROMPT_FILE" > "$REVIEW_FILE"
  elif command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
    log "Auto-detected: IBM Bob CLI with BOBSHELL_API_KEY"
    cat "$PROMPT_FILE" | bob --accept-license --auth-method api-key > "$REVIEW_FILE"
  elif command -v bob >/dev/null 2>&1; then
    log "Auto-detected: IBM Bob CLI (no BOBSHELL_API_KEY set)"
    cat "$PROMPT_FILE" | bob > "$REVIEW_FILE"
  else
    log "BobShell not found; writing dry-run review"
    cat > "$REVIEW_FILE" <<EOF
# BobShell Commit Review - Dry Run

BobShell was not executed because no Bob command is available.

The integration wrapper completed these steps:

- Loaded skills from \`.bob/skills/\`
- Created prompt file \`${PROMPT_FILE}\`
- Created diff file \`${DIFF_FILE}\`

Configure \`BOBSHELL_COMMAND\` or install Bob Shell to enable real reviews.
EOF
  fi

  strip_bob_thinking "$REVIEW_FILE"

  [ -s "$REVIEW_FILE" ] || die "Review file is empty: $REVIEW_FILE"
  log "Review written to $REVIEW_FILE ($(wc -l < "$REVIEW_FILE") lines)"
}

# ── Main ──────────────────────────────────────────────────────────────────────

main() {
  need_cmd git
  mkdir -p "$WORK_DIR"

  checkout_rules
  fetch_commit_diff
  build_prompt
  run_bobshell

  log "BobShell commit review completed"
}

main "$@"

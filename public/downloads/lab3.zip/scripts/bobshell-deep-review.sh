#!/usr/bin/env bash
# bobshell-deep-review.sh
#
# Performs a comprehensive code review of an entire branch using Bob Shell
# with all custom rules. Analyzes all source files for quality, security,
# architecture, and best practices.
#
# Equivalent of the GitHub Actions "deep-branch-review.yml" workflow.
#
# Required environment variables:
#   BOBSHELL_API_KEY       – Bob API key (Scope = Inference)
#
# Optional:
#   BRANCH                 – branch to review (default: current branch)
#   FILE_PATTERN           – file pattern to review (default: **/*.py,**/*.js,**/*.ts,**/*.java,**/*.go)
#   BOBSHELL_COMMAND       – override the Bob execution command
#   BOBSHELL_BB_TOKEN      – Repository Access Token (for creating issues)
#   BITBUCKET_WORKSPACE    – workspace slug (for creating issues)
#   BITBUCKET_REPO_SLUG    – repo slug (for creating issues)

set -Eeuo pipefail

log() { printf '[bobshell-deep] %s\n' "$*"; }
die() { printf '[bobshell-deep] ERROR: %s\n' "$*" >&2; exit 1; }

API_BASE="https://api.bitbucket.org/2.0"

bb_post_json() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" \
      -H 'Content-Type: application/json' -X POST "$@"
  else
    curl -fsS -u "${BITBUCKET_EMAIL:-${BITBUCKET_USERNAME:-}}:${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}" \
      -H 'Content-Type: application/json' -X POST "$@"
  fi
}

# ── Load rules ────────────────────────────────────────────────────────────────

load_rules_content() {
  local skills_dir="${BITBUCKET_CLONE_DIR:-.}/.bob/skills"
  local rules_dir="${BITBUCKET_CLONE_DIR:-.}/bobshell-rules/rules"

  if [ -n "${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}" ]; then
    local custom_path="${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}"
    if [ -d "$custom_path" ]; then
      skills_dir="$custom_path"
    fi
  fi

  # New convention: .bob/skills/*/SKILL.md
  local skill_files
  skill_files=$(find "$skills_dir" -name 'SKILL.md' -type f 2>/dev/null | sort)

  if [ -n "$skill_files" ]; then
    echo "$skill_files" | while IFS= read -r file; do
      local skill_name
      skill_name=$(basename "$(dirname "$file")")
      printf '\n### Skill: %s\n\n' "$skill_name"
      python3 -c "
import sys
text = open(sys.argv[1], encoding='utf-8').read()
if text.startswith('---'):
    end = text.find('---', 3)
    if end != -1:
        text = text[end+3:].lstrip('\n')
print(text)
" "$file"
      printf '\n'
    done
    return
  fi

  # Legacy fallback
  if [ -d "$rules_dir" ]; then
    find "$rules_dir" -type f -name '*.md' | sort | while IFS= read -r file; do
      printf '\n### %s\n\n' "$(basename "$file")"
      cat "$file"
      printf '\n'
    done
  fi
}

# ── Strip Bob's thinking blocks ───────────────────────────────────────────────

strip_bob_thinking() {
  local file="$1"
  [ -f "$file" ] || return 0
  if command -v python3 >/dev/null 2>&1; then
    local tmp; tmp=$(mktemp)
    python3 - "$file" > "$tmp" <<'PYEOF'
import re, sys
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()

idx = text.rfind('[using tool attempt_completion')
if idx != -1:
    m = re.search(r'---output---\s*', text[idx:])
    if m:
        text = text[idx + m.end():]
    else:
        text = text[idx:]
        text = re.sub(r'^\[using tool attempt_completion[^\]]*\]\s*', '', text)
else:
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
    text = re.sub(r'\[using tool[^\]]*\]', '', text)
    text = re.sub(r'---output---', '', text)
    text = re.sub(r'Read lines \d+-\d+ of \d+ from \S+', '', text)

text = text.strip() + '\n'
sys.stdout.write(text)
PYEOF
    mv "$tmp" "$file"
  else
    local tmp; tmp=$(mktemp)
    sed -e 's/\[using tool.*\]//g' -e 's/---output---//g' "$file" > "$tmp"
    mv "$tmp" "$file"
  fi
}

# ── Run BobShell ──────────────────────────────────────────────────────────────

run_bob_review() {
  local prompt_file="$1"
  local output_file="$2"

  if [ -n "${BOBSHELL_COMMAND:-}" ]; then
    sh -c "$BOBSHELL_COMMAND" < "$prompt_file" > "$output_file"
  elif command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
    cat "$prompt_file" | bob --accept-license --auth-method api-key > "$output_file"
  elif command -v bob >/dev/null 2>&1; then
    cat "$prompt_file" | bob > "$output_file"
  else
    printf '# Deep Review - Dry Run\n\nBob Shell is not available.\n' > "$output_file"
  fi

  strip_bob_thinking "$output_file"
}

# ── Create Bitbucket issue ────────────────────────────────────────────────────

create_bitbucket_issue() {
  local title="$1"
  local content="$2"

  if [ -z "${BITBUCKET_WORKSPACE:-}" ] || [ -z "${BITBUCKET_REPO_SLUG:-}" ]; then
    log "Skipping issue creation (BITBUCKET_WORKSPACE/REPO_SLUG not set)"
    return
  fi

  if [ -z "${BOBSHELL_BB_TOKEN:-}" ] && [ -z "${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}" ]; then
    log "Skipping issue creation (no auth token available)"
    return
  fi

  local payload
  payload=$(python3 - "$title" "$content" <<'PYEOF'
import json, sys
title, content = sys.argv[1], sys.argv[2]
# Truncate if too long for Bitbucket
if len(content) > 50000:
    content = content[:50000] + "\n\n... (truncated)"
print(json.dumps({
    "title": title,
    "content": {"raw": content},
    "kind": "task",
    "priority": "major"
}))
PYEOF
  )

  local url="${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/issues"
  local response
  response=$(bb_post_json "$url" --data "$payload" 2>&1) || {
    log "WARNING: Failed to create issue"
    return
  }

  local issue_id
  issue_id=$(echo "$response" | python3 -c "import sys, json; print(json.load(sys.stdin).get('id', 'unknown'))" 2>/dev/null || echo "unknown")
  log "Created issue #${issue_id}"
}

# ── Main ──────────────────────────────────────────────────────────────────────

main() {
  command -v git >/dev/null 2>&1 || die "git is required"

  local branch="${BRANCH:-$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo 'unknown')}"
  local file_pattern="${FILE_PATTERN:-**/*.py,**/*.js,**/*.ts,**/*.java,**/*.go}"
  local work_dir=".bobshell"
  local reviews_dir="$work_dir/reviews"
  local report_file="bobshell-deep-review.md"

  mkdir -p "$work_dir" "$reviews_dir"

  log "Deep review of branch: $branch"
  log "File pattern: $file_pattern"

  # 1. Load rules
  local rules_content
  rules_content=$(load_rules_content)
  local rules_count
  rules_count=$(echo "$rules_content" | grep -c '###' || echo 0)
  log "Loaded $rules_count rules"

  # 2. Collect source files
  log "Collecting source files..."
  local files_list="$work_dir/files_to_review.txt"
  > "$files_list"

  IFS=',' read -ra PATTERNS <<< "$file_pattern"
  local file_count=0

  for pattern in "${PATTERNS[@]}"; do
    local basename_pattern
    basename_pattern=$(echo "${pattern}" | sed 's|.*/||')
    while IFS= read -r file; do
      if [ -f "$file" ]; then
        echo "$file" >> "$files_list"
        file_count=$((file_count + 1))
      fi
    done < <(find . -path "./.git" -prune -o -path "./node_modules" -prune -o -path "./.bobshell" -prune -o -type f -name "${basename_pattern}" -print 2>/dev/null)
  done

  log "Found $file_count file(s) to review"

  if [ "$file_count" -eq 0 ]; then
    log "No files found matching pattern"
    printf '# Deep Branch Review Report\n\n**Branch:** %s\n\nNo files found matching pattern: %s\n' "$branch" "$file_pattern" > "$report_file"
    exit 0
  fi

  # 3. Analyze files in batches
  local batch_num=0
  while IFS= read -r file; do
    [ -z "$file" ] && continue

    batch_num=$((batch_num + 1))
    log "--- Batch ${batch_num}: ${file} ---"

    [ -f "$file" ] || { log "  WARNING: File not found: $file"; continue; }

    local prompt_file="$work_dir/review_prompt_${batch_num}.md"
    {
      printf '# Deep Code Review\n\n'
      printf 'File: %s\n\n' "$file"
      printf '## Review Rules\n\n'
      printf '%s\n\n' "$rules_content"
      printf '## Code to Review\n\n```\n'
      cat "$file"
      printf '\n```\n\n'
      printf '## Instructions\n\n'
      printf 'Perform a comprehensive review applying ALL custom rules.\n'
      printf 'Focus on: Security vulnerabilities, Architecture issues, Code Quality, Best Practices.\n'
      printf 'For each issue found, specify: severity (CRITICAL/HIGH/MEDIUM/LOW), location (line number if possible), and recommended fix.\n'
    } > "$prompt_file"

    log "  Running Bob review..."
    run_bob_review "$prompt_file" "$reviews_dir/review_${batch_num}.md"

    local review_size
    review_size=$(wc -c < "$reviews_dir/review_${batch_num}.md" 2>/dev/null || echo 0)
    log "  Review complete: ${review_size} bytes"

    [ "$batch_num" -ge 20 ] && { log "Reached batch limit (20 files)"; break; }
  done < "$files_list"

  # 4. Generate comprehensive report
  log "Generating comprehensive report..."
  {
    printf '# Deep Branch Review Report\n\n'
    printf '**Branch:** %s\n' "$branch"
    printf '**Repository:** %s/%s\n' "${BITBUCKET_WORKSPACE:-local}" "${BITBUCKET_REPO_SLUG:-local}"
    printf '**Date:** %s\n' "$(date -u +"%Y-%m-%d %H:%M:%S UTC" 2>/dev/null || date)"
    printf '**Files Analyzed:** %s\n' "$batch_num"
    printf '**Rules Applied:** %s\n\n' "$rules_count"
    printf '---\n\n'
  } > "$report_file"

  for review_file in "$reviews_dir"/*.md; do
    if [ -f "$review_file" ]; then
      cat "$review_file" >> "$report_file"
      printf '\n---\n\n' >> "$report_file"
    fi
  done

  local report_size
  report_size=$(wc -c < "$report_file" 2>/dev/null || echo 0)
  log "Report generated: ${report_size} bytes → ${report_file}"

  # 5. Optionally create a Bitbucket issue with summary
  if [ -n "${BITBUCKET_WORKSPACE:-}" ] && [ -n "${BITBUCKET_REPO_SLUG:-}" ]; then
    local issue_title="Deep Code Review: ${branch} branch - $(date -u +"%Y-%m-%d" 2>/dev/null || date +"%Y-%m-%d")"
    local issue_content
    issue_content=$(head -c 50000 "$report_file")
    create_bitbucket_issue "$issue_title" "$issue_content"
  fi

  log "Deep review completed"
}

main "$@"

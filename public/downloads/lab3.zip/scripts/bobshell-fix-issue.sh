#!/usr/bin/env bash
# bobshell-fix-issue.sh
#
# Takes an "issue" (a problem statement), asks Bob Shell to fix it, creates a
# branch, commits the changes, opens a pull request in Bitbucket, and documents
# the solution.
#
# ── Issue source (Bitbucket-native by default) ───────────────────────────────
# Bitbucket native Issues are deprecated (removed 2026-08-20), so by default the
# issue is provided as plain text via pipeline variables — no Jira account
# needed:
#   ISSUE_TITLE   – short title of the problem (REQUIRED in native mode)
#   ISSUE_BODY    – longer description of the problem (optional)
#
# Optional Jira mode (enterprise track): if JIRA_ISSUE_KEY and the JIRA_* creds
# are set, the issue is fetched from Jira Cloud instead and a comment is posted
# back to the Jira issue.
#
# Required environment variables (always):
#   BITBUCKET_WORKSPACE    – Bitbucket workspace slug
#   BITBUCKET_REPO_SLUG    – repository slug
#   BOBSHELL_API_KEY       – Bob API key (Scope = Inference)
#   BOBSHELL_BB_TOKEN      – Repository Access Token with pullrequest:write, repository:write
#
# Optional:
#   TARGET_BRANCH          – base branch for the fix PR (default: master)
#   BOBSHELL_COMMAND       – override the Bob execution command
#   JIRA_ISSUE_KEY / JIRA_BASE_URL / JIRA_USER_EMAIL / JIRA_API_TOKEN
#                          – enable the optional Jira track
#   ISSUE_ID               – legacy alias for JIRA_ISSUE_KEY

set -Eeuo pipefail

log() { printf '[bobshell-fix-issue] %s\n' "$*"; }
die() { printf '[bobshell-fix-issue] ERROR: %s\n' "$*" >&2; exit 1; }

API_BASE="https://api.bitbucket.org/2.0"

bb_curl() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" "$@"
  else
    curl -fsS -u "$(bitbucket_auth_user):$(bitbucket_auth_secret)" "$@"
  fi
}

bb_post_json() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" \
      -H 'Content-Type: application/json' -X POST "$@"
  else
    curl -fsS -u "$(bitbucket_auth_user):$(bitbucket_auth_secret)" \
      -H 'Content-Type: application/json' -X POST "$@"
  fi
}

bitbucket_auth_user() {
  printf '%s' "${BITBUCKET_EMAIL:-${BITBUCKET_USERNAME:-}}"
}

bitbucket_auth_secret() {
  printf '%s' "${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}"
}

# ── Jira API helpers (only used in the optional Jira track) ───────────────────

jira_curl() {
  curl -fsS -u "${JIRA_USER_EMAIL}:${JIRA_API_TOKEN}" \
    -H 'Accept: application/json' "$@"
}

jira_post_json() {
  curl -fsS -u "${JIRA_USER_EMAIL}:${JIRA_API_TOKEN}" \
    -H 'Accept: application/json' \
    -H 'Content-Type: application/json' -X POST "$@"
}

fetch_jira_issue() {
  local issue_key="$1"
  local out_file="$2"
  log "Fetching Jira issue ${issue_key}"
  jira_curl "${JIRA_BASE_URL}/rest/api/3/issue/${issue_key}" > "$out_file"
}

extract_jira_issue_info() {
  local issue_file="$1"
  python3 - "$issue_file" <<'PYEOF'
import sys, json

with open(sys.argv[1]) as fh:
    data = json.load(fh)

fields = data.get('fields', {})
title = fields.get('summary', 'Unknown')

desc_adf = fields.get('description')
if desc_adf and isinstance(desc_adf, dict):
    parts = []
    for block in desc_adf.get('content', []):
        for inline in block.get('content', []):
            if inline.get('type') == 'text':
                parts.append(inline.get('text', ''))
    content = '\n'.join(parts) if parts else 'No description provided.'
else:
    content = str(desc_adf) if desc_adf else 'No description provided.'

issue_type = (fields.get('issuetype') or {}).get('name', 'Task')
priority = (fields.get('priority') or {}).get('name', 'Medium')
labels = ', '.join(fields.get('labels', []))

print(f"Title: {title}")
print(f"Type: {issue_type}")
print(f"Priority: {priority}")
print(f"Labels: {labels}")
print(f"Description:\n{content}")
PYEOF
}

comment_on_jira_issue() {
  local issue_key="$1"
  local message="$2"
  local payload
  payload=$(python3 -c "
import json, sys
msg = sys.argv[1]
print(json.dumps({
    'body': {
        'type': 'doc',
        'version': 1,
        'content': [{
            'type': 'paragraph',
            'content': [{'type': 'text', 'text': msg}]
        }]
    }
}))
" "$message")

  jira_post_json "${JIRA_BASE_URL}/rest/api/3/issue/${issue_key}/comment" \
    --data "$payload" >/dev/null 2>&1 || log "WARNING: Failed to comment on Jira issue"
}

# ── Slug helper ───────────────────────────────────────────────────────────────

slugify() {
  printf '%s' "$1" \
    | tr '[:upper:]' '[:lower:]' \
    | sed -E 's/[^a-z0-9]+/-/g; s/^-+//; s/-+$//' \
    | cut -c1-40
}

# ── Create pull request ──────────────────────────────────────────────────────

create_pull_request() {
  local title="$1"
  local description="$2"
  local source_branch="$3"
  local target_branch="$4"
  local payload
  payload=$(python3 - "$title" "$description" "$source_branch" "$target_branch" <<'PYEOF'
import json, sys
title, desc, src, dst = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
print(json.dumps({
    "title": title,
    "description": desc,
    "source": {"branch": {"name": src}},
    "destination": {"branch": {"name": dst}},
    "close_source_branch": True
}))
PYEOF
  )

  local url="${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests"
  local response
  response=$(bb_post_json "$url" --data "$payload" 2>&1)
  local pr_id
  pr_id=$(echo "$response" | python3 -c "import sys, json; print(json.load(sys.stdin).get('id', 'unknown'))" 2>/dev/null || echo "unknown")
  log "Created PR #${pr_id}"
  echo "$pr_id"
}

# ── Load skills/rules ─────────────────────────────────────────────────────────

load_rules_content() {
  local skills_dir="${BITBUCKET_CLONE_DIR:-.}/.bob/skills"
  local rules_dir="${BITBUCKET_CLONE_DIR:-.}/bobshell-rules/rules"

  if [ -n "${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}" ]; then
    local custom_path="${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}"
    if [ -d "$custom_path" ]; then
      skills_dir="$custom_path"
    fi
  fi

  local skill_files
  skill_files=$(find "$skills_dir" -name 'SKILL.md' -type f 2>/dev/null | sort)

  if [ -n "$skill_files" ]; then
    echo "$skill_files" | while IFS= read -r file; do
      local skill_name
      skill_name=$(basename "$(dirname "$file")")
      printf '\n### Skill: %s\n\n' "$skill_name"
      python3 -c "
import sys
text = open(sys.argv[1], encoding='utf-8').read()
if text.startswith('---'):
    end = text.find('---', 3)
    if end != -1:
        text = text[end+3:].lstrip('\n')
print(text)
" "$file"
      printf '\n'
    done
    return
  fi

  if [ -d "$rules_dir" ]; then
    find "$rules_dir" -type f -name '*.md' | sort | while IFS= read -r file; do
      printf '\n### %s\n\n' "$(basename "$file")"
      cat "$file"
      printf '\n'
    done
  fi
}

# ── Run Bob ───────────────────────────────────────────────────────────────────

run_bob_fix() {
  local prompt_file="$1"
  local log_file="${2:-.bobshell/fix-issue-bob.log}"
  mkdir -p "$(dirname "$log_file")"

  # Fixing an issue requires Bob in AGENTIC (file-editing) mode — NOT the review
  # wrapper (bob-ci-runner.sh only prints to stdout and never edits files).
  # We therefore IGNORE BOBSHELL_COMMAND here. Use BOBSHELL_FIX_COMMAND only if
  # you have a custom agentic command.
  local effective_cmd="${BOBSHELL_FIX_COMMAND:-}"

  if [ -z "$effective_cmd" ]; then
    if command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
      effective_cmd="bob --accept-license --auth-method api-key --yolo"
    elif command -v bob >/dev/null 2>&1; then
      effective_cmd="bob --yolo"
    else
      die "Bob Shell not found. Install it or set BOBSHELL_FIX_COMMAND."
    fi
  fi

  log "Running Bob (agentic) to fix issue: $effective_cmd"
  log "Bob output -> $log_file"
  sh -c "$effective_cmd" < "$prompt_file" > "$log_file" 2>&1 \
    || log "WARNING: Bob exited non-zero (see $log_file)"
}

# ── Main ──────────────────────────────────────────────────────────────────────

main() {
  : "${BITBUCKET_WORKSPACE:?BITBUCKET_WORKSPACE must be set}"
  : "${BITBUCKET_REPO_SLUG:?BITBUCKET_REPO_SLUG must be set}"

  command -v python3 >/dev/null 2>&1 || die "python3 is required"
  command -v curl    >/dev/null 2>&1 || die "curl is required"
  command -v git     >/dev/null 2>&1 || die "git is required"

  local target_branch="${TARGET_BRANCH:-master}"
  local work_dir=".bobshell"
  mkdir -p "$work_dir"

  # Decide the issue source: Jira (optional) vs Bitbucket-native (default).
  local jira_key="${JIRA_ISSUE_KEY:-${ISSUE_ID:-}}"
  local mode issue_ref issue_title issue_info

  if [ -n "$jira_key" ] && [ -n "${JIRA_BASE_URL:-}" ] && \
     [ -n "${JIRA_USER_EMAIL:-}" ] && [ -n "${JIRA_API_TOKEN:-}" ]; then
    mode="jira"
    issue_ref="$jira_key"
    log "Issue source: Jira ($jira_key)"
    local issue_file="$work_dir/issue.json"
    fetch_jira_issue "$jira_key" "$issue_file"
    issue_info=$(extract_jira_issue_info "$issue_file")
    issue_title=$(echo "$issue_info" | head -1 | sed 's/^Title: //')
  else
    mode="native"
    : "${ISSUE_TITLE:?ISSUE_TITLE must be set (native mode), or provide JIRA_ISSUE_KEY + JIRA_* for Jira mode}"
    issue_title="$ISSUE_TITLE"
    issue_ref="$(slugify "$ISSUE_TITLE")"
    [ -n "$issue_ref" ] || issue_ref="issue"
    log "Issue source: Bitbucket-native (typed). Title: ${issue_title}"
    issue_info=$(printf 'Title: %s\nType: Task\nPriority: Medium\nDescription:\n%s' \
      "$issue_title" "${ISSUE_BODY:-No description provided.}")
  fi

  log "Issue info:"
  echo "$issue_info"

  local slug
  slug="$(slugify "$issue_title")"
  [ -n "$slug" ] || slug="$issue_ref"

  # Configure git
  git config --global user.name "bitbucket-pipelines[bot]"
  git config --global user.email "pipelines@bitbucket.org"
  # Ignore file-mode (exec bit) changes so `chmod +x scripts/*.sh` in the
  # pipeline does not create spurious, content-less diffs.
  git config core.fileMode false

  # Create fix branch
  local fix_branch="fix/${slug}"
  git checkout -b "$fix_branch" 2>/dev/null || git checkout "$fix_branch"
  log "Created branch: $fix_branch"

  # Load skills/rules
  local rules_content
  rules_content=$(load_rules_content)

  # Build prompt
  local doc_path="docs/fixes/${slug}.md"
  local prompt_file="$work_dir/fix-issue-prompt.md"
  {
    printf '# BobShell Issue Fix Request\n\n'
    printf 'Fix the following issue (%s): %s\n\n' "$issue_ref" "$issue_title"
    printf 'Repository: %s/%s\n\n' "$BITBUCKET_WORKSPACE" "$BITBUCKET_REPO_SLUG"
    printf '## Coding Standards to Follow\n\n'
    printf '%s\n\n' "$rules_content"
    printf '## Issue Details\n\n'
    printf '%s\n\n' "$issue_info"
    printf '## Instructions\n\n'
    printf 'Please analyze this issue and make all necessary code changes to fix it.\n\n'
    printf 'Requirements:\n'
    printf '1. Ensure the changes are complete and resolve the issue\n'
    printf '2. Follow all coding standards above\n'
    printf '3. Do not introduce new violations of the coding standards\n'
    printf '4. Write clean, maintainable, and secure code\n'
    printf '5. Consider edge cases and error handling\n'
    printf '6. Document the solution: create a Markdown file at "%s" describing\n' "$doc_path"
    printf '   the root cause, the fix you applied, and how to verify it.\n'
    printf '7. CRITICAL: ONLY modify local files. Do NOT use git commands.\n'
  } > "$prompt_file"

  # Run Bob
  run_bob_fix "$prompt_file" "$work_dir/fix-issue-bob.log"

  # Check for changes
  if [ -n "$(git status --porcelain)" ]; then
    local changed_files
    changed_files=$(git diff --name-only | tr '\n' ', ' | sed 's/,$//')
    log "Changes detected: $changed_files"

    git add -A
    git reset .bobshell/ 2>/dev/null || true
    git reset .bob/ 2>/dev/null || true
    git commit -m "Fix ${issue_ref}: ${issue_title}

Automatically generated by BobShell."

    # Push
    if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
      git remote set-url origin "https://x-token-auth:${BOBSHELL_BB_TOKEN}@bitbucket.org/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}.git"
    fi
    git push -u origin "$fix_branch" 2>&1 || die "Failed to push branch"

    # Create PR — the description documents the solution
    local pr_description="This PR was automatically generated by BobShell to fix the issue **${issue_ref}**.

## Issue Details
${issue_info}

## Changes
BobShell analyzed the issue and applied fixes to the following files:
**Changed files:** ${changed_files}

A detailed write-up of the root cause and the fix is included at \`${doc_path}\`.

Resolves ${issue_ref}"

    local pr_id
    pr_id=$(create_pull_request "Fix: ${issue_title}" "$pr_description" "$fix_branch" "$target_branch")

    # In Jira mode, also comment back on the Jira issue
    if [ "$mode" = "jira" ]; then
      comment_on_jira_issue "$issue_ref" "BobShell created Bitbucket pull request #${pr_id} with a proposed fix. Changed files: ${changed_files}. Please review the PR."
    fi

    log "Done. Opened PR #${pr_id} from ${fix_branch} into ${target_branch}."
  else
    log "No changes were made by Bob"
    if [ "$mode" = "jira" ]; then
      comment_on_jira_issue "$issue_ref" "BobShell analyzed this issue but did not generate any code changes. Manual intervention may be required."
    fi
  fi

  log "BobShell fix-issue completed"
}

main "$@"

#!/usr/bin/env bash
# bobshell-fix-review.sh
#
# Reads review comments on a Bitbucket PR, asks Bob Shell to fix the code,
# commits the changes, and posts a summary back to the PR.
#
# Equivalent of the GitHub Actions "fix-pr-reviews-with-bob.yml" workflow.
#
# Required environment variables:
#   BITBUCKET_WORKSPACE    – Bitbucket workspace slug
#   BITBUCKET_REPO_SLUG    – repository slug
#   BITBUCKET_PR_ID or PR_ID – pull request ID to process
#   BOBSHELL_API_KEY       – Bob API key (Scope = Inference)
#   BOBSHELL_BB_TOKEN      – Repository Access Token with pullrequest:write, repository:write
#
# Optional:
#   BOBSHELL_COMMAND       – override the Bob execution command

set -Eeuo pipefail

log() { printf '[bobshell-fix] %s\n' "$*"; }
die() { printf '[bobshell-fix] ERROR: %s\n' "$*" >&2; exit 1; }

API_BASE="https://api.bitbucket.org/2.0"

bb_curl() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" "$@"
  else
    curl -fsS -u "$(bitbucket_auth_user):$(bitbucket_auth_secret)" "$@"
  fi
}

bitbucket_auth_user() {
  printf '%s' "${BITBUCKET_EMAIL:-${BITBUCKET_USERNAME:-}}"
}

bitbucket_auth_secret() {
  printf '%s' "${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}"
}

json_escape_file() {
  local file="$1"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$file" <<'PY'
import json, sys
from pathlib import Path
print(json.dumps(Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")))
PY
  elif command -v node >/dev/null 2>&1; then
    node -e "const fs=require('fs'); console.log(JSON.stringify(fs.readFileSync(process.argv[1], 'utf8')))" "$file"
  else
    die "python3 or node required for JSON escaping"
  fi
}

# ── Fetch PR comments ────────────────────────────────────────────────────────

fetch_pr_comments() {
  local pr_id="$1"
  local out_file="$2"
  log "Fetching comments for PR #${pr_id}"
  bb_curl \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}/comments?pagelen=100" \
    > "$out_file"
}

# ── Extract actionable comments ──────────────────────────────────────────────

extract_review_comments() {
  local comments_file="$1"
  python3 - "$comments_file" <<'PYEOF'
import sys, json

with open(sys.argv[1]) as fh:
    data = json.load(fh)

comments = data.get('values', [])
review_items = []

for comment in comments:
    raw = (comment.get('content') or {}).get('raw') or ''
    # Skip bot comments
    if '<!-- bobshell-ack -->' in raw:
        continue
    # Skip empty
    if not raw.strip():
        continue

    inline = comment.get('inline')
    if inline:
        path = inline.get('path', 'unknown')
        line = inline.get('to') or inline.get('from') or '?'
        review_items.append(f"File: {path}\nLine: {line}\nComment: {raw}\n---")
    else:
        # General comment — only include if it looks like feedback
        lower = raw.lower()
        if any(kw in lower for kw in ['fix', 'change', 'should', 'could', 'please', 'issue', 'bug', 'error', 'wrong', 'improve', 'refactor']):
            review_items.append(f"General comment: {raw}\n---")

if not review_items:
    print("No actionable review comments found.")
else:
    print('\n'.join(review_items))
PYEOF
}

# ── Get PR source branch ─────────────────────────────────────────────────────

get_pr_source_branch() {
  local pr_id="$1"
  bb_curl \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}" \
    | python3 -c "import sys, json; print(json.load(sys.stdin)['source']['branch']['name'])"
}

# ── Post comment ─────────────────────────────────────────────────────────────

post_pr_comment() {
  local pr_id="$1"
  local message="$2"
  local escaped
  escaped=$(python3 -c "import json, sys; print(json.dumps(sys.argv[1]))" "$message")
  local payload
  payload=$(printf '{"content":{"raw":%s}}' "$escaped")

  local url="${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}/comments"
  local http_status
  http_status=$(bb_curl -s -o /dev/null -w "%{http_code}" \
    -H 'Content-Type: application/json' \
    -X POST "$url" --data "$payload")

  if [ "$http_status" = "201" ] || [ "$http_status" = "200" ]; then
    log "Comment posted successfully (HTTP $http_status)"
  else
    log "WARNING: Failed to post comment (HTTP $http_status)"
  fi
}

# ── Run BobShell to fix code ─────────────────────────────────────────────────

run_bob_fix() {
  local prompt_file="$1"
  local log_file="${2:-.bobshell/fix-review-bob.log}"
  mkdir -p "$(dirname "$log_file")"

  # Fixing review comments requires Bob in AGENTIC (file-editing) mode — NOT the
  # review wrapper (bob-ci-runner.sh only prints to stdout and never edits files).
  # We therefore IGNORE BOBSHELL_COMMAND here. Use BOBSHELL_FIX_COMMAND only if
  # you have a custom agentic command.
  local effective_cmd="${BOBSHELL_FIX_COMMAND:-}"

  if [ -z "$effective_cmd" ]; then
    if command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
      effective_cmd="bob --accept-license --auth-method api-key --yolo"
    elif command -v bob >/dev/null 2>&1; then
      effective_cmd="bob --yolo"
    else
      die "Bob Shell not found. Install it or set BOBSHELL_FIX_COMMAND."
    fi
  fi

  log "Running Bob (agentic) to fix code: $effective_cmd"
  log "Bob output -> $log_file"
  sh -c "$effective_cmd" < "$prompt_file" > "$log_file" 2>&1 \
    || log "WARNING: Bob exited non-zero (see $log_file)"
}

# ── Load rules ────────────────────────────────────────────────────────────────

load_rules_content() {
  local skills_dir="${BITBUCKET_CLONE_DIR:-.}/.bob/skills"
  local rules_dir="${BITBUCKET_CLONE_DIR:-.}/bobshell-rules/rules"

  if [ -n "${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}" ]; then
    local custom_path="${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}"
    if [ -d "$custom_path" ]; then
      skills_dir="$custom_path"
    fi
  fi

  local skill_files
  skill_files=$(find "$skills_dir" -name 'SKILL.md' -type f 2>/dev/null | sort)

  if [ -n "$skill_files" ]; then
    echo "$skill_files" | while IFS= read -r file; do
      local skill_name
      skill_name=$(basename "$(dirname "$file")")
      printf '\n### Skill: %s\n\n' "$skill_name"
      python3 -c "
import sys
text = open(sys.argv[1], encoding='utf-8').read()
if text.startswith('---'):
    end = text.find('---', 3)
    if end != -1:
        text = text[end+3:].lstrip('\n')
print(text)
" "$file"
      printf '\n'
    done
    return
  fi

  if [ -d "$rules_dir" ]; then
    find "$rules_dir" -type f -name '*.md' | sort | while IFS= read -r file; do
      printf '\n### %s\n\n' "$(basename "$file")"
      cat "$file"
      printf '\n'
    done
  fi
}

# ── Main ──────────────────────────────────────────────────────────────────────

main() {
  : "${BITBUCKET_WORKSPACE:?BITBUCKET_WORKSPACE must be set}"
  : "${BITBUCKET_REPO_SLUG:?BITBUCKET_REPO_SLUG must be set}"

  local pr_id="${BITBUCKET_PR_ID:-${PR_ID:-}}"
  [ -n "$pr_id" ] || die "PR_ID or BITBUCKET_PR_ID must be set"

  command -v python3 >/dev/null 2>&1 || die "python3 is required"
  command -v curl    >/dev/null 2>&1 || die "curl is required"
  command -v git     >/dev/null 2>&1 || die "git is required"

  local work_dir=".bobshell"
  mkdir -p "$work_dir"

  # 1. Fetch and extract review comments
  local comments_file="$work_dir/pr-comments.json"
  fetch_pr_comments "$pr_id" "$comments_file"

  local review_text
  review_text=$(extract_review_comments "$comments_file")
  log "Review comments extracted:"
  echo "$review_text"

  if echo "$review_text" | grep -q "No actionable review comments found"; then
    log "No actionable comments to fix"
    post_pr_comment "$pr_id" "🤖 **BobShell** analyzed the PR comments but found no actionable review feedback to address."
    exit 0
  fi

  # 2. Get source branch and ensure we're on it
  local source_branch
  source_branch=$(get_pr_source_branch "$pr_id") || source_branch="${BITBUCKET_BRANCH:-main}"
  log "PR source branch: $source_branch"

  # Configure git
  git config --global user.name "bitbucket-pipelines[bot]"
  git config --global user.email "pipelines@bitbucket.org"
  # Ignore file-mode (exec bit) changes so `chmod +x scripts/*.sh` in the
  # pipeline does not create spurious, content-less diffs.
  git config core.fileMode false

  # 3. Load rules
  local rules_content
  rules_content=$(load_rules_content)

  # 4. Build fix prompt
  local prompt_file="$work_dir/fix-prompt.md"
  {
    printf '# BobShell Fix Request\n\n'
    printf 'Address PR review comments for PR #%s\n\n' "$pr_id"
    printf '## Coding Standards to Follow\n\n'
    printf '%s\n\n' "$rules_content"
    printf '## Review Comments to Address\n\n'
    printf '%s\n\n' "$review_text"
    printf '## Instructions\n\n'
    printf 'Please analyze all the review comments above and make the necessary code changes to address each point of feedback.\n'
    printf 'For each comment:\n'
    printf '1. Understand the concern or suggestion\n'
    printf '2. Make the appropriate code changes following the coding standards above\n'
    printf '3. Ensure the changes follow best practices (security, architecture, code quality)\n'
    printf '4. Make sure all related code is updated consistently\n'
    printf '5. Do not introduce new violations of the coding standards\n'
    printf '6. CRITICAL: ONLY modify local files. Do NOT use git commands.\n'
  } > "$prompt_file"

  # 5. Run Bob to fix code
  run_bob_fix "$prompt_file" "$work_dir/fix-review-bob.log"

  # 6. Check for changes
  if [ -n "$(git status --porcelain)" ]; then
    local changed_files
    changed_files=$(git diff --name-only | tr '\n' ', ' | sed 's/,$//')
    log "Changes detected: $changed_files"

    git add -A
    git reset .bobshell/ 2>/dev/null || true
    git reset .bob/ 2>/dev/null || true
    git commit -m "Address review comments on PR #${pr_id}

Automatically generated by BobShell to address review feedback."

    # Push using token auth
    if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
      git remote set-url origin "https://x-token-auth:${BOBSHELL_BB_TOKEN}@bitbucket.org/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}.git"
    fi
    git push origin HEAD 2>&1 || log "WARNING: Failed to push changes"

    post_pr_comment "$pr_id" "✅ **BobShell** has addressed the review comments and pushed changes.

**Changed files:** ${changed_files}

Please review the updated code."
  else
    log "No changes were made by Bob"
    post_pr_comment "$pr_id" "🤖 **BobShell** analyzed the review comments but did not generate any code changes. The comments may require manual intervention."
  fi

  log "BobShell fix-review completed"
}

main "$@"

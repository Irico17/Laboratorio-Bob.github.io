#!/usr/bin/env bash
# bobshell-label-issue.sh
#
# Analyzes a Jira issue and updates its labels/priority using Bob Shell.
#
# Uses Jira Cloud REST API v3 for issue management (Bitbucket native issues
# are deprecated and will be removed August 20, 2026).
#
# Required environment variables:
#   JIRA_ISSUE_KEY         – Jira issue key to label (e.g., BOB-42)
#   JIRA_BASE_URL          – Jira Cloud base URL (e.g., https://your-domain.atlassian.net)
#   JIRA_USER_EMAIL        – Atlassian account email
#   JIRA_API_TOKEN         – Jira API token
#   BOBSHELL_API_KEY       – Bob API key (Scope = Inference)
#
# Optional:
#   BOBSHELL_COMMAND       – override the Bob execution command
#   ISSUE_ID               – legacy alias for JIRA_ISSUE_KEY
#   BITBUCKET_WORKSPACE    – (for logging only)
#   BITBUCKET_REPO_SLUG    – (for logging only)

set -Eeuo pipefail

log() { printf '[bobshell-label-issue] %s\n' "$*"; }
die() { printf '[bobshell-label-issue] ERROR: %s\n' "$*" >&2; exit 1; }

# ── Jira API helpers ─────────────────────────────────────────────────────────

jira_curl() {
  curl -fsS -u "${JIRA_USER_EMAIL}:${JIRA_API_TOKEN}" \
    -H 'Accept: application/json' "$@"
}

jira_put_json() {
  curl -fsS -u "${JIRA_USER_EMAIL}:${JIRA_API_TOKEN}" \
    -H 'Accept: application/json' \
    -H 'Content-Type: application/json' -X PUT "$@"
}

jira_post_json() {
  curl -fsS -u "${JIRA_USER_EMAIL}:${JIRA_API_TOKEN}" \
    -H 'Accept: application/json' \
    -H 'Content-Type: application/json' -X POST "$@"
}

# ── Fetch issue from Jira ────────────────────────────────────────────────────

fetch_issue() {
  local issue_key="$1"
  local out_file="$2"
  jira_curl \
    "${JIRA_BASE_URL}/rest/api/3/issue/${issue_key}" \
    > "$out_file"
}

# ── Fetch available labels and priorities ────────────────────────────────────

fetch_priorities() {
  jira_curl "${JIRA_BASE_URL}/rest/api/3/priority" 2>/dev/null \
    | python3 -c "
import sys, json
data = json.load(sys.stdin)
for p in data:
    print(p.get('name', ''))
" 2>/dev/null || echo ""
}

# ── Strip Bob thinking ───────────────────────────────────────────────────────

strip_bob_thinking() {
  local file="$1"
  [ -f "$file" ] || return 0

  python3 - "$file" <<'PYEOF'
import sys, re

filepath = sys.argv[1]
with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
    text = f.read()

# Strategy: find the last attempt_completion marker and take everything after ---output---
pattern = r'\[using tool attempt_completion[^\]]*\]\s*---output---\s*'
parts = re.split(pattern, text, flags=re.IGNORECASE)
if len(parts) > 1:
    text = parts[-1].strip()
else:
    # Fallback: strip <thinking>...</thinking> blocks
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL).strip()

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(text)
PYEOF
}

# ── Run Bob ──────────────────────────────────────────────────────────────────

run_bob_label() {
  local prompt_file="$1"
  local output_file="$2"

  if [ -n "${BOBSHELL_COMMAND:-}" ]; then
    sh -c "$BOBSHELL_COMMAND" < "$prompt_file" > "$output_file"
  elif command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
    cat "$prompt_file" | bob --accept-license --auth-method api-key > "$output_file"
  elif command -v bob >/dev/null 2>&1; then
    cat "$prompt_file" | bob > "$output_file"
  else
    printf '{"labels": ["bug"], "priority": "Medium"}\n' > "$output_file"
  fi

  strip_bob_thinking "$output_file"
}

# ── Comment on Jira issue ────────────────────────────────────────────────────

comment_on_issue() {
  local issue_key="$1"
  local message="$2"
  local payload
  payload=$(python3 -c "
import json, sys
msg = sys.argv[1]
print(json.dumps({
    'body': {
        'type': 'doc',
        'version': 1,
        'content': [{
            'type': 'paragraph',
            'content': [{'type': 'text', 'text': msg}]
        }]
    }
}))
" "$message")

  jira_post_json "${JIRA_BASE_URL}/rest/api/3/issue/${issue_key}/comment" \
    --data "$payload" >/dev/null 2>&1 || log "WARNING: Failed to comment on Jira issue"
}

# ── Update Jira issue labels and priority ────────────────────────────────────

update_issue() {
  local issue_key="$1"
  local labels_json="$2"
  local priority="$3"

  local payload
  payload=$(python3 - "$labels_json" "$priority" <<'PYEOF'
import json, sys
labels_str, priority = sys.argv[1], sys.argv[2]
try:
    labels = json.loads(labels_str)
except:
    labels = []

update_ops = {}
fields = {}

# Add labels (Jira labels are simple string arrays)
if labels:
    update_ops['labels'] = [{'add': l} for l in labels]

# Set priority if known
if priority and priority != 'unknown':
    fields['priority'] = {'name': priority}

result = {}
if update_ops:
    result['update'] = update_ops
if fields:
    result['fields'] = fields

print(json.dumps(result))
PYEOF
  )

  jira_put_json "${JIRA_BASE_URL}/rest/api/3/issue/${issue_key}" \
    --data "$payload" >/dev/null 2>&1 || log "WARNING: Failed to update Jira issue"
}

# ── Main ──────────────────────────────────────────────────────────────────────

main() {
  # Accept JIRA_ISSUE_KEY or legacy ISSUE_ID
  local issue_key="${JIRA_ISSUE_KEY:-${ISSUE_ID:-}}"
  [ -n "$issue_key" ] || die "JIRA_ISSUE_KEY (or ISSUE_ID) must be set"

  # Validate Jira credentials
  : "${JIRA_BASE_URL:?JIRA_BASE_URL must be set (e.g., https://your-domain.atlassian.net)}"
  : "${JIRA_USER_EMAIL:?JIRA_USER_EMAIL must be set}"
  : "${JIRA_API_TOKEN:?JIRA_API_TOKEN must be set}"

  command -v python3 >/dev/null 2>&1 || die "python3 is required"
  command -v curl    >/dev/null 2>&1 || die "curl is required"

  local work_dir=".bobshell"
  mkdir -p "$work_dir"

  # 1. Fetch issue from Jira
  local issue_file="$work_dir/issue.json"
  fetch_issue "$issue_key" "$issue_file"

  local issue_title issue_body current_labels current_priority issue_type
  issue_title=$(python3 -c "import sys, json; print(json.load(open(sys.argv[1])).get('fields', {}).get('summary', 'Unknown'))" "$issue_file")
  issue_body=$(python3 -c "
import sys, json
fields = json.load(open(sys.argv[1])).get('fields', {})
desc = fields.get('description')
if desc and isinstance(desc, dict):
    parts = []
    for block in desc.get('content', []):
        for inline in block.get('content', []):
            if inline.get('type') == 'text':
                parts.append(inline.get('text', ''))
    print('\\n'.join(parts) if parts else 'No description')
else:
    print(str(desc) if desc else 'No description')
" "$issue_file")
  current_labels=$(python3 -c "import sys, json; print(', '.join(json.load(open(sys.argv[1])).get('fields', {}).get('labels', [])))" "$issue_file")
  current_priority=$(python3 -c "import sys, json; print((json.load(open(sys.argv[1])).get('fields', {}).get('priority') or {}).get('name', 'Medium'))" "$issue_file")
  issue_type=$(python3 -c "import sys, json; print((json.load(open(sys.argv[1])).get('fields', {}).get('issuetype') or {}).get('name', 'Task'))" "$issue_file")

  log "Issue ${issue_key}: ${issue_title} (type=${issue_type}, priority=${current_priority}, labels=${current_labels})"

  # 2. Fetch available priorities
  local priorities
  priorities=$(fetch_priorities)

  # 3. Build prompt
  local prompt_file="$work_dir/label-issue-prompt.md"
  {
    printf 'Analyze this Jira issue and classify it.\n\n'
    printf '**Issue %s:** %s\n\n' "$issue_key" "$issue_title"
    printf '**Description:**\n%s\n\n' "$issue_body"
    printf '**Current classification:**\n'
    printf '- Type: %s\n' "$issue_type"
    printf '- Priority: %s\n' "$current_priority"
    printf '- Labels: %s\n\n' "${current_labels:-none}"
    printf '**Available priorities:** %s\n' "$(echo "$priorities" | tr '\n' ', ')"
    printf '**Suggested labels:** bug, enhancement, security, performance, documentation, ui, api, testing, infrastructure, technical-debt\n\n'
    printf '**Instructions:**\n'
    printf 'Respond with ONLY a JSON object like this:\n'
    printf '{"labels": ["bug", "security"], "priority": "High"}\n\n'
    printf 'Choose the most appropriate labels (1-3) and priority based on the issue content.\n'
  } > "$prompt_file"

  # 4. Run Bob
  local output_file="$work_dir/label-issue-output.txt"
  run_bob_label "$prompt_file" "$output_file"

  local bob_output
  bob_output=$(cat "$output_file")
  log "Bob output: $bob_output"

  # 5. Extract classification
  local new_labels_json new_priority
  new_labels_json=$(echo "$bob_output" | python3 -c "
import sys, json, re
text = sys.stdin.read()
m = re.search(r'\{[^}]+\}', text)
if m:
    d = json.loads(m.group())
    print(json.dumps(d.get('labels', [])))
else:
    print('[]')
" 2>/dev/null || echo "[]")

  new_priority=$(echo "$bob_output" | python3 -c "
import sys, json, re
text = sys.stdin.read()
m = re.search(r'\{[^}]+\}', text)
if m:
    d = json.loads(m.group())
    print(d.get('priority', 'unknown'))
else:
    print('unknown')
" 2>/dev/null || echo "unknown")

  log "Classification: labels=${new_labels_json}, priority=${new_priority}"

  # 6. Validate priority against available ones
  if [ -n "$priorities" ]; then
    echo "$priorities" | grep -qw "$new_priority" || new_priority="unknown"
  fi

  # 7. Update issue in Jira
  local labels_list
  labels_list=$(echo "$new_labels_json" | python3 -c "import sys, json; print(', '.join(json.loads(sys.stdin.read())))" 2>/dev/null || echo "")

  if [ "$new_labels_json" != "[]" ] || [ "$new_priority" != "unknown" ]; then
    update_issue "$issue_key" "$new_labels_json" "$new_priority"
    log "Issue updated"

    comment_on_issue "$issue_key" "Automatic Classification by BobShell: Labels: ${labels_list:-none}. Priority: ${new_priority}. This classification was selected based on the issue content. Feel free to adjust it manually."
  else
    log "Could not determine classification"
    comment_on_issue "$issue_key" "BobShell analyzed this issue but couldn't determine appropriate classification. Please classify manually."
  fi

  log "BobShell label-issue completed"
}

main "$@"

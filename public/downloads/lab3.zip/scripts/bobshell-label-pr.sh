#!/usr/bin/env bash
# bobshell-label-pr.sh
#
# Analyzes a Bitbucket pull request and suggests labels/tags via a PR comment.
#
# Equivalent of the GitHub Actions "label-new-prs.yml" workflow.
#
# NOTE: Bitbucket Cloud PRs don't have native labels like GitHub. This script
# posts a structured comment with suggested categories instead.
#
# Required environment variables:
#   BITBUCKET_WORKSPACE    – Bitbucket workspace slug
#   BITBUCKET_REPO_SLUG    – repository slug
#   PR_ID or BITBUCKET_PR_ID – pull request ID to label
#   BOBSHELL_API_KEY       – Bob API key (Scope = Inference)
#   BOBSHELL_BB_TOKEN      – Repository Access Token

set -Eeuo pipefail

log() { printf '[bobshell-label-pr] %s\n' "$*"; }
die() { printf '[bobshell-label-pr] ERROR: %s\n' "$*" >&2; exit 1; }

API_BASE="https://api.bitbucket.org/2.0"

bb_curl() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" "$@"
  else
    curl -fsS -u "${BITBUCKET_EMAIL:-${BITBUCKET_USERNAME:-}}:${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}" "$@"
  fi
}

bb_post_json() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" \
      -H 'Content-Type: application/json' -X POST "$@"
  else
    curl -fsS -u "${BITBUCKET_EMAIL:-${BITBUCKET_USERNAME:-}}:${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}" \
      -H 'Content-Type: application/json' -X POST "$@"
  fi
}

# ── Fetch PR details ─────────────────────────────────────────────────────────

fetch_pr_details() {
  local pr_id="$1"
  local out_file="$2"
  bb_curl \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}" \
    > "$out_file"
}

fetch_pr_diff_stat() {
  local pr_id="$1"
  bb_curl \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}/diffstat" \
    2>/dev/null || echo "{}"
}

extract_pr_info() {
  local pr_file="$1"
  python3 - "$pr_file" <<'PYEOF'
import sys, json

with open(sys.argv[1]) as fh:
    data = json.load(fh)

title = data.get('title', 'Unknown')
description = (data.get('description') or 'No description')
author = data.get('author', {}).get('display_name', 'Unknown')
source = data.get('source', {}).get('branch', {}).get('name', 'unknown')
dest = data.get('destination', {}).get('branch', {}).get('name', 'unknown')

print(f"Title: {title}")
print(f"Author: {author}")
print(f"Source: {source}")
print(f"Destination: {dest}")
print(f"Description: {description}")
PYEOF
}

extract_changed_files() {
  local diffstat_json="$1"
  echo "$diffstat_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for f in data.get('values', []):
    old = (f.get('old') or {}).get('path', '')
    new = (f.get('new') or {}).get('path', '')
    path = new or old
    lines_added = f.get('lines_added', 0)
    lines_removed = f.get('lines_removed', 0)
    print(f'- {path} (+{lines_added}/-{lines_removed})')
" 2>/dev/null || echo "- (unable to fetch changed files)"
}

# ── Post comment ─────────────────────────────────────────────────────────────

post_pr_comment() {
  local pr_id="$1"
  local message="$2"
  local payload
  payload=$(python3 -c "import json, sys; print(json.dumps({'content': {'raw': sys.argv[1]}}))" "$message")

  local url="${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}/comments"
  bb_post_json "$url" --data "$payload" >/dev/null 2>&1 || log "WARNING: Failed to post comment"
}

# ── Strip Bob's thinking blocks ───────────────────────────────────────────────

strip_bob_thinking() {
  local file="$1"
  [ -f "$file" ] || return 0
  if command -v python3 >/dev/null 2>&1; then
    local tmp; tmp=$(mktemp)
    python3 - "$file" > "$tmp" <<'PYEOF'
import re, sys
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()

idx = text.rfind('[using tool attempt_completion')
if idx != -1:
    m = re.search(r'---output---\s*', text[idx:])
    if m:
        text = text[idx + m.end():]
    else:
        text = text[idx:]
        text = re.sub(r'^\[using tool attempt_completion[^\]]*\]\s*', '', text)
else:
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
    text = re.sub(r'\[using tool[^\]]*\]', '', text)
    text = re.sub(r'---output---', '', text)
    text = re.sub(r'Read lines \d+-\d+ of \d+ from \S+', '', text)

text = text.strip() + '\n'
sys.stdout.write(text)
PYEOF
    mv "$tmp" "$file"
  else
    local tmp; tmp=$(mktemp)
    sed -e 's/\[using tool.*\]//g' -e 's/---output---//g' "$file" > "$tmp"
    mv "$tmp" "$file"
  fi
}

# ── Run Bob ───────────────────────────────────────────────────────────────────

run_bob_label() {
  local prompt_file="$1"
  local output_file="$2"

  if [ -n "${BOBSHELL_COMMAND:-}" ]; then
    sh -c "$BOBSHELL_COMMAND" < "$prompt_file" > "$output_file"
  elif command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
    cat "$prompt_file" | bob --accept-license --auth-method api-key > "$output_file"
  elif command -v bob >/dev/null 2>&1; then
    cat "$prompt_file" | bob > "$output_file"
  else
    printf 'bug, enhancement\n' > "$output_file"
  fi

  strip_bob_thinking "$output_file"
}

# ── Main ──────────────────────────────────────────────────────────────────────

main() {
  : "${BITBUCKET_WORKSPACE:?BITBUCKET_WORKSPACE must be set}"
  : "${BITBUCKET_REPO_SLUG:?BITBUCKET_REPO_SLUG must be set}"

  local pr_id="${BITBUCKET_PR_ID:-${PR_ID:-}}"
  [ -n "$pr_id" ] || die "PR_ID or BITBUCKET_PR_ID must be set"

  command -v python3 >/dev/null 2>&1 || die "python3 is required"
  command -v curl    >/dev/null 2>&1 || die "curl is required"

  local work_dir=".bobshell"
  mkdir -p "$work_dir"

  # 1. Fetch PR details
  local pr_file="$work_dir/pr-details.json"
  fetch_pr_details "$pr_id" "$pr_file"

  local pr_info
  pr_info=$(extract_pr_info "$pr_file")
  log "PR info:"
  echo "$pr_info"

  # 2. Fetch changed files
  local diffstat_json
  diffstat_json=$(fetch_pr_diff_stat "$pr_id")
  local changed_files
  changed_files=$(extract_changed_files "$diffstat_json")

  # 3. Define available categories
  local categories="Available categories for this PR:
- bug: Fix for a broken feature or incorrect behavior
- enhancement: New feature or improvement to existing functionality
- refactor: Code restructuring without behavior change
- security: Security-related changes
- documentation: Documentation updates
- performance: Performance improvements
- testing: Test additions or modifications
- infrastructure: CI/CD, build, deployment changes
- dependency: Dependency updates
- breaking-change: Changes that break backward compatibility
- hotfix: Urgent fix for production issues"

  # 4. Build prompt
  local prompt_file="$work_dir/label-prompt.md"
  {
    printf 'Analyze this Bitbucket pull request and suggest appropriate categories.\n\n'
    printf '**Pull Request Information:**\n'
    printf '%s\n\n' "$pr_info"
    printf '**Changed Files:**\n'
    printf '%s\n\n' "$changed_files"
    printf '%s\n\n' "$categories"
    printf '**Instructions:**\n'
    printf '1. Analyze the PR title, description, and changed files\n'
    printf '2. Select the most relevant categories from the list above\n'
    printf '3. You can suggest multiple categories if appropriate\n'
    printf '4. CRITICAL: Only use categories from the list above\n'
    printf '5. Output ONLY the category names, one per line, nothing else\n\n'
    printf 'Suggested categories:\n'
  } > "$prompt_file"

  # 5. Run Bob
  local output_file="$work_dir/label-output.txt"
  run_bob_label "$prompt_file" "$output_file"

  local bob_output
  bob_output=$(cat "$output_file")
  log "Bob output: $bob_output"

  # 6. Extract valid categories
  local valid_categories="bug enhancement refactor security documentation performance testing infrastructure dependency breaking-change hotfix"
  local selected=""

  while IFS= read -r line; do
    line=$(echo "$line" | sed -E 's/^[-*][[:space:]]*//' | sed -E 's/^[[:space:]]*//;s/[[:space:]]*$//' | tr '[:upper:]' '[:lower:]')
    for valid in $valid_categories; do
      if [ "$line" = "$valid" ]; then
        if [ -z "$selected" ]; then
          selected="$valid"
        else
          selected="${selected}, ${valid}"
        fi
      fi
    done
  done <<< "$bob_output"

  if [ -z "$selected" ]; then
    log "No valid categories extracted"
    selected="enhancement"
  fi

  log "Selected categories: $selected"

  # 7. Post comment with labels
  local comment="🏷️ **Categorización Automática**

BobShell ha analizado este Pull Request y sugiere las siguientes categorías:

$(echo "$selected" | tr ',' '\n' | sed 's/^[[:space:]]*//' | sed 's/^/- `/' | sed 's/$/`/')

Estas categorías fueron sugeridas con base en el título, la descripción y los archivos modificados en el PR.
Si consideras que las categorías son incorrectas, puedes ajustarlas manualmente en cualquier momento.

<!-- bobshell-label -->"

  post_pr_comment "$pr_id" "$comment"

  log "BobShell label-pr completed"
}

main "$@"

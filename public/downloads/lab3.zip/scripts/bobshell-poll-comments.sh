#!/usr/bin/env bash
# bobshell-poll-comments.sh
#
# Scans every open PR for /bob commands in comments and responds.
#
# Supported commands:
#
#   /bob
#       Triggers a full code review via the "bob-review" custom pipeline.
#
#   /bob fix
#       Reads review comments and auto-fixes them via the "bob-fix-review" pipeline.
#
#   /bob label
#       Auto-categorizes the PR via the "bob-label-pr" pipeline.
#
#   /bob deep-review
#       Triggers a comprehensive deep review via the "bob-deep-review" pipeline.
#
#   /bob <any question>
#       BobShell answers inline, e.g.:
#         /bob resume this PR
#         /bob explain why we are using a singleton here
#         /bob are there any security issues in the diff?
#
# Designed to run as a Bitbucket scheduled pipeline every 30–60 minutes.
# After each handled /bob, an ACK comment with a hidden marker is posted
# so the same command is never processed twice.
#
# Required environment variables:
#   BITBUCKET_WORKSPACE    – your Bitbucket workspace slug
#   BITBUCKET_REPO_SLUG    – the repository slug
#   BITBUCKET_USERNAME     – Bitbucket account username or email
#   BITBUCKET_API_KEY      – Atlassian API key with Bitbucket access
#   BITBUCKET_APY_KEY      – accepted alias for BITBUCKET_API_KEY
#   BITBUCKET_APP_PASSWORD – legacy fallback
#
# Required for Q&A mode:
#   BOBSHELL_COMMAND=bash scripts/bob-ci-runner.sh
#   BOBSHELL_API_KEY  – API key from bob.ibm.com (Scope = Inference)
#
# Optional:
#   BOBSHELL_POLL_LOOKBACK  – minutes to look back for /bob commands (default 90)

set -Eeuo pipefail

# Marker embedded in acknowledgment comments so the poller can recognise them
BOT_ACK_MARKER="<!-- bobshell-ack -->"
LOOKBACK_MINUTES="${BOBSHELL_POLL_LOOKBACK:-90}"
API_BASE="https://api.bitbucket.org/2.0"

# ── helpers ──────────────────────────────────────────────────────────────────

log() { printf '[bobshell-poll] %s\n' "$*"; }
die() { printf '[bobshell-poll] ERROR: %s\n' "$*" >&2; exit 1; }

bb_get() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" "$@"
  else
    curl -fsS -u "$(bitbucket_auth_user):$(bitbucket_auth_secret)" "$@"
  fi
}

bb_post_json() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" \
      -H 'Content-Type: application/json' -X POST "$@"
  else
    curl -fsS -u "$(bitbucket_auth_user):$(bitbucket_auth_secret)" \
      -H 'Content-Type: application/json' -X POST "$@"
  fi
}

bitbucket_auth_user() {
  printf '%s' "${BITBUCKET_EMAIL:-${BITBUCKET_USERNAME:-}}"
}

bitbucket_auth_secret() {
  printf '%s' "${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}"
}

# ── Bitbucket API wrappers ────────────────────────────────────────────────────

get_open_pr_ids() {
  bb_get \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests?state=OPEN&pagelen=50" \
    | python3 -c "
import sys, json
data = json.load(sys.stdin)
for pr in data.get('values', []):
    print(pr['id'])
"
}

get_pr_source_branch() {
  local pr_id="$1"
  bb_get \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}" \
    | python3 -c "import sys, json; print(json.load(sys.stdin)['source']['branch']['name'])"
}

fetch_pr_comments() {
  local pr_id="$1"
  local out_file="$2"
  bb_get \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}/comments?pagelen=100" \
    > "$out_file"
}

fetch_pr_diff() {
  local pr_id="$1"
  local out_file="$2"
  bb_get \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}/diff" \
    > "$out_file" 2>/dev/null || echo "" > "$out_file"
}

# Post an acknowledgment comment containing BOT_ACK_MARKER.
# $1 – PR ID
# $2 – message text (raw Markdown; must NOT already contain BOT_ACK_MARKER)
# $3 – (optional) parent comment ID to reply to
post_comment_with_ack() {
  local pr_id="$1"
  local message="$2"
  local parent_id="${3:-}"
  local body
  body=$(python3 - "$message" "$BOT_ACK_MARKER" "$parent_id" <<'PYEOF'
import json, sys
msg       = sys.argv[1]
marker    = sys.argv[2]
parent_id = sys.argv[3]
payload   = {"content": {"raw": f"{msg}\n\n{marker}"}}
if parent_id:
    payload["parent"] = {"id": int(parent_id)}
print(json.dumps(payload))
PYEOF
)
  bb_post_json \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${pr_id}/comments" \
    --data "$body" \
    >/dev/null
}

trigger_custom_pipeline() {
  local pipeline_name="$1"
  local branch="$2"
  shift 2
  # Remaining args are key=value pairs for variables
  local payload
  payload=$(python3 - "$pipeline_name" "$branch" "$@" <<'PYEOF'
import json, sys
args = sys.argv[1:]
pipeline_name = args[0]
branch = args[1]
variables = []
for kv in args[2:]:
    key, value = kv.split('=', 1)
    variables.append({"key": key, "value": value, "secured": False})
print(json.dumps({
    "target": {
        "type": "pipeline_ref_target",
        "ref_type": "branch",
        "ref_name": branch,
        "selector": {"type": "custom", "pattern": pipeline_name}
    },
    "variables": variables
}))
PYEOF
)
  bb_post_json \
    "${API_BASE}/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pipelines/" \
    --data "$payload" \
    >/dev/null
}

trigger_bob_review_pipeline() {
  local pr_id="$1"
  local branch="$2"
  trigger_custom_pipeline "bob-review" "$branch" "PR_ID=${pr_id}"
}

trigger_bob_fix_pipeline() {
  local pr_id="$1"
  local branch="$2"
  trigger_custom_pipeline "bob-fix-review" "$branch" "PR_ID=${pr_id}"
}

trigger_bob_label_pipeline() {
  local pr_id="$1"
  local branch="$2"
  trigger_custom_pipeline "bob-label-pr" "$branch" "PR_ID=${pr_id}"
}

trigger_bob_deep_review_pipeline() {
  local pr_id="$1"
  local branch="$2"
  trigger_custom_pipeline "bob-deep-review" "$branch"
}

# ── Decision logic ────────────────────────────────────────────────────────────
# Prints a JSON object to stdout describing the action needed for this PR:
#   {"type": "none"}
#   {"type": "review",       "comment_id": <int>}
#   {"type": "fix",          "comment_id": <int>}
#   {"type": "label",        "comment_id": <int>}
#   {"type": "deep-review",  "comment_id": <int>}
#   {"type": "question",     "text": "<the question text>", "comment_id": <int>}

get_pending_bob_action() {
  local comments_file="$1"
  python3 - "$comments_file" "$LOOKBACK_MINUTES" "$BOT_ACK_MARKER" <<'PYEOF'
import sys, json, re
from datetime import datetime, timezone, timedelta

json_file  = sys.argv[1]
lookback   = timedelta(minutes=int(sys.argv[2]))
bot_marker = sys.argv[3]

# Recognized subcommands that trigger specific pipelines
SUBCOMMANDS = {'fix', 'label', 'deep-review'}

with open(json_file) as fh:
    data = json.load(fh)

comments  = data.get('values', [])
now       = datetime.now(timezone.utc)
# Each entry: (timestamp, action_type, extra_text, comment_id)
bob_commands = []
ack_times    = []

for comment in comments:
    raw    = (comment.get('content') or {}).get('raw') or ''
    ts_str = comment.get('created_on', '')
    cid    = comment.get('id')
    try:
        ts = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
    except ValueError:
        continue

    # Match /bob optionally followed by text.
    # Accepts /bob at the start of a line or preceded by whitespace.
    m = re.search(r'(?:^|\s)/bob(?:\s+(.+?))?(?:\s*$)', raw.strip(), re.IGNORECASE | re.MULTILINE)
    if m and (now - ts) <= lookback:
        rest = m.group(1).strip() if m.group(1) else None

        if rest is None:
            bob_commands.append((ts, 'review', None, cid))
        elif rest.lower() in SUBCOMMANDS:
            bob_commands.append((ts, rest.lower(), None, cid))
        else:
            bob_commands.append((ts, 'question', rest, cid))

    if bot_marker in raw:
        ack_times.append(ts)

if not bob_commands:
    print(json.dumps({"type": "none"}))
    sys.exit(0)

bob_commands.sort(key=lambda x: x[0])
last_ts, last_type, last_text, last_id = bob_commands[-1]

if any(a > last_ts for a in ack_times):
    print(json.dumps({"type": "none"}))
    sys.exit(0)

result = {"type": last_type, "comment_id": last_id}
if last_text:
    result["text"] = last_text
print(json.dumps(result))
PYEOF
}

# ── Q&A handler ──────────────────────────────────────────────────────────────
# Answers a /bob <question> inline and posts the response as a PR comment.

answer_bob_question() {
  local pr_id="$1"
  local question="$2"
  local parent_id="${3:-}"

  # Resolve the command to use — same priority order as bobshell-pr-review.sh
  local effective_cmd="${BOBSHELL_COMMAND:-}"
  if [ -z "$effective_cmd" ]; then
    if command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
      effective_cmd="cat | bob --accept-license --auth-method api-key"
    elif command -v bob >/dev/null 2>&1; then
      effective_cmd="cat | bob"
    fi
  fi

  if [ -z "$effective_cmd" ]; then
    local msg="🤖 **BobShell Q&A** (question: *${question}*)

\`BOBSHELL_COMMAND\` is not configured and \`bob\` was not found. Set one of:
\`\`\`
BOBSHELL_COMMAND=bash scripts/bob-ci-runner.sh
BOBSHELL_API_KEY=<key from bob.ibm.com>
\`\`\`"
    post_comment_with_ack "$pr_id" "$msg" "$parent_id"
    return
  fi

  local diff_tmp="" prompt_tmp="" answer_tmp=""
  diff_tmp=$(mktemp)
  prompt_tmp=$(mktemp)
  answer_tmp=$(mktemp)
  trap 'rm -f "${diff_tmp:-}" "${prompt_tmp:-}" "${answer_tmp:-}"' RETURN

  fetch_pr_diff "$pr_id" "$diff_tmp"

  python3 - "$pr_id" "$question" "$diff_tmp" > "$prompt_tmp" <<'PYEOF'
import sys
pr_id    = sys.argv[1]
question = sys.argv[2]
diff_f   = sys.argv[3]

diff = open(diff_f, encoding="utf-8", errors="replace").read()
# Truncate large diffs to keep the prompt manageable
if len(diff) > 15000:
    diff = diff[:15000] + "\n\n... (diff truncated to 15000 chars) ..."

print(f"""# BobShell Q&A – Pull Request #{pr_id}

You are BobShell, an AI coding assistant. A developer has asked a question about this pull request.

## Developer's Question

{question}

## Pull Request Context

- PR ID: {pr_id}

## Pull Request Diff

```diff
{diff}
```

## Instructions

Answer the developer's question concisely and helpfully based on the code changes shown above.
Respond in Markdown format suitable for a Bitbucket PR comment.
""")
PYEOF

  sh -c "$effective_cmd" < "$prompt_tmp" > "$answer_tmp" \
    || { log "  → command failed for Q&A; posting error notice"; printf '**BobShell error:** the command failed while answering your question.\n' > "$answer_tmp"; }

  # Strip Bob's internal thinking blocks before posting the answer
  if command -v python3 >/dev/null 2>&1; then
    local clean_tmp
    clean_tmp=$(mktemp)
    python3 - "$answer_tmp" > "$clean_tmp" <<'PYEOF'
import re, sys
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()

idx = text.rfind('[using tool attempt_completion')
if idx != -1:
    m = re.search(r'---output---\s*', text[idx:])
    if m:
        text = text[idx + m.end():]
    else:
        text = text[idx:]
        text = re.sub(r'^\[using tool attempt_completion[^\]]*\]\s*', '', text)
else:
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
    text = re.sub(r'\[using tool[^\]]*\]', '', text)
    text = re.sub(r'---output---', '', text)
    text = re.sub(r'Read lines \d+-\d+ of \d+ from \S+', '', text)

text = text.strip() + '\n'
sys.stdout.write(text)
PYEOF
    mv "$clean_tmp" "$answer_tmp"
  else
    local clean_tmp
    clean_tmp=$(mktemp)
    sed -e 's/\[using tool.*\]//g' -e 's/---output---//g' "$answer_tmp" > "$clean_tmp"
    mv "$clean_tmp" "$answer_tmp"
  fi

  local answer
  answer=$(cat "$answer_tmp")

  local msg="🤖 **BobShell** (responding to: *${question}*)

${answer}"

  post_comment_with_ack "$pr_id" "$msg" "$parent_id"
  log "  → Answer posted for PR #${pr_id}"
}

# ── Main ──────────────────────────────────────────────────────────────────────

main() {
  : "${BITBUCKET_WORKSPACE:?BITBUCKET_WORKSPACE must be set}"
  : "${BITBUCKET_REPO_SLUG:?BITBUCKET_REPO_SLUG must be set}"

  # Validate that at least one auth method is configured
  if [ -z "${BOBSHELL_BB_TOKEN:-}" ] && [ -z "${BITBUCKET_API_KEY:-}${BITBUCKET_APY_KEY:-}" ]; then
    die "No Bitbucket auth configured. Set BOBSHELL_BB_TOKEN (recommended) or BITBUCKET_API_KEY."
  fi

  command -v python3 >/dev/null 2>&1 || die "python3 is required"
  command -v curl    >/dev/null 2>&1 || die "curl is required"

  log "Scanning open PRs in ${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG} (lookback: ${LOOKBACK_MINUTES} min)"

  local open_prs
  open_prs=$(get_open_pr_ids) || die "Failed to fetch open PRs"

  if [ -z "$open_prs" ]; then
    log "No open PRs found."
    exit 0
  fi

  comments_tmp=$(mktemp)
  trap 'rm -f "$comments_tmp"' EXIT


  local triggered=0
  local answered=0

  while IFS= read -r pr_id; do
    [ -z "$pr_id" ] && continue
    log "Checking PR #${pr_id}..."

    fetch_pr_comments "$pr_id" "$comments_tmp" 2>/dev/null \
      || { log "  → Could not fetch comments, skipping."; continue; }

    local action action_type comment_id
    action=$(get_pending_bob_action "$comments_tmp")
    action_type=$(python3 -c "import sys, json; print(json.loads(sys.argv[1])['type'])" "$action")
    comment_id=$(python3 -c "import sys, json; print(json.loads(sys.argv[1]).get('comment_id') or '')" "$action")

    case "$action_type" in
      review)
        local branch
        branch=$(get_pr_source_branch "$pr_id") || branch="main"
        log "  → /bob review triggered! Posting ack and dispatching bob-review (branch: ${branch})"
        post_comment_with_ack "$pr_id" \
          "🤖 **BobShell review triggered!** I am analysing this PR and will post a review comment shortly." \
          "$comment_id"
        trigger_bob_review_pipeline "$pr_id" "$branch"
        triggered=$((triggered + 1))
        ;;
      fix)
        local branch
        branch=$(get_pr_source_branch "$pr_id") || branch="main"
        log "  → /bob fix triggered! Dispatching bob-fix-review (branch: ${branch})"
        post_comment_with_ack "$pr_id" \
          "🤖 **BobShell fix triggered!** I am reading the review comments and will push fixes shortly." \
          "$comment_id"
        trigger_bob_fix_pipeline "$pr_id" "$branch"
        triggered=$((triggered + 1))
        ;;
      label)
        local branch
        branch=$(get_pr_source_branch "$pr_id") || branch="main"
        log "  → /bob label triggered! Dispatching bob-label-pr"
        post_comment_with_ack "$pr_id" \
          "🤖 **BobShell label triggered!** I am analyzing this PR and will post category suggestions shortly." \
          "$comment_id"
        trigger_bob_label_pipeline "$pr_id" "$branch"
        triggered=$((triggered + 1))
        ;;
      deep-review)
        local branch
        branch=$(get_pr_source_branch "$pr_id") || branch="main"
        log "  → /bob deep-review triggered! Dispatching bob-deep-review (branch: ${branch})"
        post_comment_with_ack "$pr_id" \
          "🤖 **BobShell deep review triggered!** I am performing a comprehensive analysis. This may take a few minutes." \
          "$comment_id"
        trigger_bob_deep_review_pipeline "$pr_id" "$branch"
        triggered=$((triggered + 1))
        ;;
      question)
        local question
        question=$(python3 -c "import sys, json; print(json.loads(sys.argv[1])['text'])" "$action")
        log "  → /bob question detected: ${question}"
        answer_bob_question "$pr_id" "$question" "$comment_id"
        answered=$((answered + 1))
        ;;
      none)
        log "  → No pending /bob command."
        ;;
    esac
  done <<< "$open_prs"

  log "Scan complete. Reviews triggered: ${triggered}, Questions answered: ${answered}"
}

main "$@"

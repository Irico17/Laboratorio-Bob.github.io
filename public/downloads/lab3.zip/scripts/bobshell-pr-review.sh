#!/usr/bin/env bash
set -Eeuo pipefail

log() {
  printf '[bobshell-review] %s\n' "$*"
}

die() {
  printf '[bobshell-review] ERROR: %s\n' "$*" >&2
  exit 1
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"
}

normalize_bool() {
  case "${1:-}" in
    true|TRUE|1|yes|YES) printf 'true' ;;
    *) printf 'false' ;;
  esac
}

json_escape_file() {
  local file="$1"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$file" <<'PY'
import json
import sys
from pathlib import Path

print(json.dumps(Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")))
PY
  elif command -v node >/dev/null 2>&1; then
    node -e "const fs=require('fs'); console.log(JSON.stringify(fs.readFileSync(process.argv[1], 'utf8')))" "$file"
  else
    die "Posting Bitbucket comments requires python3 or node for JSON escaping"
  fi
}

has_bitbucket_pr_context() {
  [ -n "${BITBUCKET_WORKSPACE:-}" ] &&
    [ -n "${BITBUCKET_REPO_SLUG:-}" ] &&
    [ -n "${BITBUCKET_PR_ID:-}" ] &&
    { [ -n "${BOBSHELL_BB_TOKEN:-}" ] || { [ -n "$(bitbucket_auth_user)" ] && [ -n "$(bitbucket_auth_secret)" ]; }; }
}

bitbucket_auth_user() {
  printf '%s' "${BITBUCKET_EMAIL:-${BITBUCKET_USERNAME:-}}"
}

bitbucket_auth_secret() {
  printf '%s' "${BITBUCKET_API_KEY:-${BITBUCKET_APY_KEY:-}}"
}

# Build curl auth args for Bitbucket REST API.
# Priority:
#   1. BOBSHELL_BB_TOKEN  – Bitbucket Repository Access Token (works with IBM SSO)
#   2. username:api_key   – classic Basic Auth fallback
bb_curl() {
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    curl -fsS -H "Authorization: Bearer ${BOBSHELL_BB_TOKEN}" "$@"
  else
    curl -fsS -u "$(bitbucket_auth_user):$(bitbucket_auth_secret)" "$@"
  fi
}

fetch_bitbucket_diff() {
  local url
  url="https://api.bitbucket.org/2.0/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${BITBUCKET_PR_ID}/diff"
  log "Fetching PR diff from Bitbucket API"
  bb_curl "$url" -o "$DIFF_FILE"
}

fetch_local_diff() {
  local destination="${BITBUCKET_PR_DESTINATION_BRANCH:-main}"
  log "Fetching local git diff against origin/${destination}"
  git fetch --quiet origin "$destination" || log "Could not fetch origin/${destination}; using local refs"
  if git rev-parse --verify "origin/${destination}" >/dev/null 2>&1; then
    git diff "origin/${destination}...HEAD" > "$DIFF_FILE"
  else
    git diff HEAD~1..HEAD > "$DIFF_FILE" 2>/dev/null || git diff > "$DIFF_FILE"
  fi
}

checkout_rules() {
  rm -rf "$RULES_DIR"
  mkdir -p "$WORK_DIR"

  # Priority 1: Explicit local path via env var
  if [ -n "${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}" ]; then
    local custom_path="${BOBSHELL_SKILLS_PATH:-${BOBSHELL_RULES_LOCAL_PATH:-}}"
    [ -d "$custom_path" ] || die "Skills path does not exist: $custom_path"
    log "Copying skills from $custom_path"
    cp -R "$custom_path" "$RULES_DIR"
    return
  fi

  # Priority 2: .bob/skills/ in the repo root (new convention)
  local repo_skills="${BITBUCKET_CLONE_DIR:-.}/.bob/skills"
  if [ -d "$repo_skills" ]; then
    log "Using skills from $repo_skills"
    mkdir -p "$RULES_DIR"
    cp -R "$repo_skills/." "$RULES_DIR/"
    return
  fi

  # Priority 3: Legacy bobshell-rules/ fallback
  local repo_rules="${BITBUCKET_CLONE_DIR:-.}/bobshell-rules"
  if [ -d "$repo_rules" ]; then
    log "Using legacy rules from $repo_rules (consider migrating to .bob/skills/)"
    mkdir -p "$RULES_DIR"
    cp -R "$repo_rules/." "$RULES_DIR/"
    return
  fi

  [ -n "${BOBSHELL_RULES_REPO_URL:-}" ] || die "No skills found. Add .bob/skills/ to the repo or set BOBSHELL_SKILLS_PATH"
  log "Cloning rules repository ref ${RULES_REF}"
  git clone --quiet --depth 1 --branch "$RULES_REF" "$BOBSHELL_RULES_REPO_URL" "$RULES_DIR"
}

append_rules() {
  # New convention: look for SKILL.md files (strip YAML front matter)
  local skill_files
  skill_files=$(find "$RULES_DIR" -name 'SKILL.md' -type f 2>/dev/null | sort)

  if [ -n "$skill_files" ]; then
    echo "$skill_files" | while IFS= read -r file; do
      local skill_name
      skill_name=$(basename "$(dirname "$file")")
      printf '\n### Skill: %s\n\n' "$skill_name"
      # Strip YAML front matter (everything between --- delimiters)
      python3 -c "
import sys
text = open(sys.argv[1], encoding='utf-8').read()
if text.startswith('---'):
    end = text.find('---', 3)
    if end != -1:
        text = text[end+3:].lstrip('\\n')
print(text)
" "$file"
      printf '\n'
    done
    return
  fi

  # Legacy fallback: look for rules/*.md
  local rules_path="$RULES_DIR/rules"
  if [ -d "$rules_path" ]; then
    find "$rules_path" -type f -name '*.md' | sort | while IFS= read -r file; do
      printf '\n### %s\n\n' "$(basename "$file")"
      cat "$file"
      printf '\n'
    done
    return
  fi

  log "WARNING: No SKILL.md files or rules/ directory found in $RULES_DIR"
}

build_prompt() {
  [ -f "$DIFF_FILE" ] || die "Diff file was not created: $DIFF_FILE"

  {
    printf '# BobShell Pull Request Review Request\n\n'
    printf 'You are BobShell running inside Bitbucket Pipelines. Review the pull request using the rules below.\n\n'
    printf '## Pull Request Context\n\n'
    printf -- '- Workspace: %s\n' "${BITBUCKET_WORKSPACE:-local}"
    printf -- '- Repository: %s\n' "${BITBUCKET_REPO_SLUG:-local}"
    printf -- '- Pull Request: %s\n' "${BITBUCKET_PR_ID:-local}"
    printf -- '- Source branch: %s\n' "${BITBUCKET_BRANCH:-unknown}"
    printf -- '- Destination branch: %s\n' "${BITBUCKET_PR_DESTINATION_BRANCH:-unknown}"
    printf -- '- Commit: %s\n' "${BITBUCKET_COMMIT:-unknown}"
    printf '\n## Skills & Rules\n'
    append_rules
    printf '\n## Pull Request Diff\n\n```diff\n'
    cat "$DIFF_FILE"
    printf '\n```\n'
  } > "$PROMPT_FILE"

  log "Prompt written to $PROMPT_FILE"
}

write_dry_run_review() {
  if [ "$(normalize_bool "$REQUIRE_COMMAND")" = "true" ]; then
    die "BOBSHELL_COMMAND is required because BOBSHELL_REQUIRE_COMMAND=true"
  fi

  cat > "$REVIEW_FILE" <<EOF
# BobShell Review - Dry Run

BobShell was not executed because \`BOBSHELL_COMMAND\` is not configured.

The Bitbucket integration wrapper completed these steps:

- Loaded skills from \`.bob/skills/\`
- Created prompt file \`${PROMPT_FILE}\`
- Created diff file \`${DIFF_FILE}\`

Configure \`BOBSHELL_COMMAND\` with a non-interactive BobShell command that reads the prompt from stdin and writes Markdown to stdout.

Recommendation: configure BobShell before enabling blocking review gates.
EOF
}

strip_bob_thinking() {
  # Strips Bob Shell's internal thinking blocks, tool-use metadata, and
  # ---output--- separator from a file, leaving only the clean review output.
  local file="$1"
  [ -f "$file" ] || return 0

  if command -v python3 >/dev/null 2>&1; then
    local tmp
    tmp=$(mktemp)
    python3 - "$file" > "$tmp" <<'PYEOF'
import re, sys
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()

idx = text.rfind('[using tool attempt_completion')
if idx != -1:
    m = re.search(r'---output---\s*', text[idx:])
    if m:
        text = text[idx + m.end():]
    else:
        text = text[idx:]
        text = re.sub(r'^\[using tool attempt_completion[^\]]*\]\s*', '', text)
else:
    text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
    text = re.sub(r'\[using tool[^\]]*\]', '', text)
    text = re.sub(r'---output---', '', text)
    text = re.sub(r'Read lines \d+-\d+ of \d+ from \S+', '', text)

text = text.strip() + '\n'
sys.stdout.write(text)
PYEOF
    mv "$tmp" "$file"
  else
    # sed fallback
    local tmp
    tmp=$(mktemp)
    sed -e 's/\[using tool.*\]//g' -e 's/---output---//g' "$file" > "$tmp"
    mv "$tmp" "$file"
  fi
}

run_bobshell() {
  if [ -n "${BOBSHELL_COMMAND:-}" ]; then
    log "Running BobShell command: $BOBSHELL_COMMAND"
    sh -c "$BOBSHELL_COMMAND" < "$PROMPT_FILE" > "$REVIEW_FILE"
  elif command -v bob >/dev/null 2>&1 && [ -n "${BOBSHELL_API_KEY:-}" ]; then
    # IBM Bob CLI auto-detected with API key — use non-interactive API-key mode.
    # Docs: bob.ibm.com/docs/shell/getting-started/start-bobshell-non-interactive
    log "Auto-detected: IBM Bob CLI with BOBSHELL_API_KEY → using API-key auth"
    cat "$PROMPT_FILE" | bob --accept-license --auth-method api-key > "$REVIEW_FILE"
  elif command -v bob >/dev/null 2>&1; then
    # Bob CLI in PATH but no API key — try interactive/IBMid mode (likely to fail in CI)
    log "Auto-detected: IBM Bob CLI (no BOBSHELL_API_KEY set; attempting default auth)"
    cat "$PROMPT_FILE" | bob > "$REVIEW_FILE"
  elif command -v bobshell >/dev/null 2>&1; then
    log "Auto-detected: bobshell legacy binary"
    bobshell < "$PROMPT_FILE" > "$REVIEW_FILE"
  else
    log "BobShell/bob not found and BOBSHELL_COMMAND not set; writing dry-run review"
    write_dry_run_review
  fi

  # Clean Bob's internal thinking blocks from the output
  strip_bob_thinking "$REVIEW_FILE"

  [ -s "$REVIEW_FILE" ] || die "Review file is empty: $REVIEW_FILE"
  log "Review written to $REVIEW_FILE"
}


post_bitbucket_comment() {
  case "$OUTPUT_MODE" in
    comment|both) ;;
    artifact) return 0 ;;
    *) die "Invalid BOBSHELL_OUTPUT_MODE: $OUTPUT_MODE. Use artifact, comment, or both." ;;
  esac

  if ! has_bitbucket_pr_context; then
    log "Skipping PR comment because Bitbucket PR credentials/context are incomplete"
    return 0
  fi

  local payload_file="$WORK_DIR/comment-payload.json"
  local escaped_review
  escaped_review="$(json_escape_file "$REVIEW_FILE")"
  printf '{"content":{"raw":%s}}\n' "$escaped_review" > "$payload_file"

  local url
  url="https://api.bitbucket.org/2.0/repositories/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pullrequests/${BITBUCKET_PR_ID}/comments"
  log "Posting review comment to Bitbucket PR ${BITBUCKET_PR_ID}"
  if [ -n "${BOBSHELL_BB_TOKEN:-}" ]; then
    log "Auth: Repository Access Token (BOBSHELL_BB_TOKEN)"
  else
    log "Auth: API key (user: $(bitbucket_auth_user))"
  fi

  local http_status
  http_status=$(bb_curl -s -o /dev/null -w "%{http_code}" \
    -H 'Content-Type: application/json' \
    -X POST "$url" --data-binary "@$payload_file")

  if [ "$http_status" = "201" ] || [ "$http_status" = "200" ]; then
    log "Comment posted successfully (HTTP $http_status)"
  else
    log "WARNING: Failed to post PR comment (HTTP $http_status). Review is saved as artifact: $REVIEW_FILE"
  fi
}

severity_rank() {
  case "$1" in
    critical) printf '4' ;;
    high) printf '3' ;;
    medium) printf '2' ;;
    low) printf '1' ;;
    never) printf '0' ;;
    *) die "Invalid BOBSHELL_FAIL_ON: $1. Use never, critical, high, medium, or low." ;;
  esac
}

review_has_severity_at_or_above() {
  local threshold="$1"
  local threshold_rank
  threshold_rank="$(severity_rank "$threshold")"

  [ "$threshold_rank" = "0" ] && return 1

  for severity in critical high medium low; do
    if [ "$(severity_rank "$severity")" -ge "$threshold_rank" ] &&
      grep -Eiq "(severity:[[:space:]]*$severity|\\[$severity\\]|\\b$severity\\b)" "$REVIEW_FILE"; then
      log "Detected $severity finding at or above fail threshold $threshold"
      return 0
    fi
  done

  return 1
}

main() {
  WORK_DIR="${BOBSHELL_WORK_DIR:-.bobshell}"
  RULES_DIR="$WORK_DIR/rules-repo"
  PROMPT_FILE="$WORK_DIR/prompt.md"
  DIFF_FILE="${BOBSHELL_DIFF_FILE:-$WORK_DIR/pr.diff}"
  REVIEW_FILE="${BOBSHELL_REVIEW_FILE:-bobshell-review.md}"
  OUTPUT_MODE="${BOBSHELL_OUTPUT_MODE:-both}"
  FAIL_ON="${BOBSHELL_FAIL_ON:-never}"
  RULES_REF="${BOBSHELL_RULES_REF:-main}"
  REQUIRE_COMMAND="${BOBSHELL_REQUIRE_COMMAND:-false}"

  need_cmd git
  need_cmd curl
  mkdir -p "$WORK_DIR"

  checkout_rules

  if [ -f "$DIFF_FILE" ]; then
    log "Using existing diff file: $DIFF_FILE"
  elif [ -n "${BITBUCKET_BUILD_NUMBER:-}" ]; then
    # Inside a Bitbucket Pipeline: the repo is already cloned — use local git diff.
    # This avoids needing Bitbucket API auth just to get the diff.
    log "Pipeline context detected (build #${BITBUCKET_BUILD_NUMBER}); using local git diff"
    fetch_local_diff
  elif has_bitbucket_pr_context; then
    fetch_bitbucket_diff
  else
    fetch_local_diff
  fi

  build_prompt
  run_bobshell
  post_bitbucket_comment

  if review_has_severity_at_or_above "$FAIL_ON"; then
    die "Review contains findings at or above BOBSHELL_FAIL_ON=$FAIL_ON"
  fi

  log "BobShell PR review completed"
}

main "$@"

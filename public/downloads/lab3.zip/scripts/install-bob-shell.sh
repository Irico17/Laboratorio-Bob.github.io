#!/usr/bin/env bash
set -Eeuo pipefail

log() { printf '[bob-install] %s\n' "$*"; }
die() { printf '[bob-install] ERROR: %s\n' "$*" >&2; exit 1; }

NODE_VER=$(node -p 'Number(process.versions.node.split(".")[0])' 2>/dev/null || printf 0)
log "Node version: $(node --version) (major: $NODE_VER)"
[ "$NODE_VER" -ge 20 ] || die "Node.js >= 20 required (found $NODE_VER). The pipeline image must provide it."

log "npm version: $(npm --version)"

if command -v bob >/dev/null 2>&1; then
  log "bob already installed: $(bob --version 2>/dev/null || printf 'version unavailable')"
  exit 0
fi

log "Installing Bob Shell via official installer..."
curl -fsSL https://bob.ibm.com/download/bobshell.sh -o /tmp/bobshell.sh
bash /tmp/bobshell.sh --pm npm

command -v bob >/dev/null 2>&1 || die "bob was not installed. Visit https://bob.ibm.com/download for the official install command."
log "Installed bob: $(bob --version 2>/dev/null || printf 'version unavailable')"

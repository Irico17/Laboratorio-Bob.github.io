"""
Test file for POC — intentionally contains fake credentials to trigger Bob Shell security detection.
These are NOT real credentials. They are here to validate that Bob flags them.
"""

# BAD PRACTICE: hardcoded fake API key (should be in env vars)
FAKE_API_KEY = "sk-proj-aaabbbccc111222333dddeeefff444555"
FAKE_DB_PASSWORD = "P@ssw0rd123!"
FAKE_AWS_SECRET = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

def connect_to_db():
    # BAD: password hardcoded
    connection_string = f"postgresql://admin:{FAKE_DB_PASSWORD}@localhost/mydb"
    return connection_string


def call_external_api():
    import urllib.request
    req = urllib.request.Request("https://api.example.com/data")
    # BAD: secret in header
    req.add_header("Authorization", f"Bearer {FAKE_API_KEY}")
    return req


class Config:
    # BAD: no input validation, SQL injection risk
    def get_user(self, user_id):
        return f"SELECT * FROM users WHERE id = {user_id}"

    # BAD: no rate limiting, no auth check
    def delete_all(self):
        return "DELETE FROM users"

#!/usr/bin/env bash
# run-commit-review-test.sh
#
# Local smoke test for the commit review script.
# Uses mock-bobshell.sh as the Bob command.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
REVIEW_FILE="$REPO_ROOT/bobshell-commit-review.md"

rm -rf "$REPO_ROOT/.bobshell" "$REVIEW_FILE"

chmod +x "$REPO_ROOT/scripts/bobshell-commit-review.sh" "$REPO_ROOT/tests/mock-bobshell.sh"

export BOBSHELL_RULES_LOCAL_PATH="$REPO_ROOT/bobshell-rules"
export BOBSHELL_COMMAND="'$REPO_ROOT/tests/mock-bobshell.sh'"
export BOBSHELL_COMMIT_REVIEW_FILE="$REVIEW_FILE"

"$REPO_ROOT/scripts/bobshell-commit-review.sh"

test -f "$REVIEW_FILE"
grep -q "Mock BobShell Review" "$REVIEW_FILE"
test -f "$REPO_ROOT/.bobshell/commit-prompt.md"
grep -q "security.md" "$REPO_ROOT/.bobshell/commit-prompt.md"
grep -q "code-quality.md" "$REPO_ROOT/.bobshell/commit-prompt.md"

printf 'Commit review local test passed.\n'

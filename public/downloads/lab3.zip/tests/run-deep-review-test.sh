#!/usr/bin/env bash
# run-deep-review-test.sh
#
# Local smoke test for the deep review script.
# Uses mock-bobshell.sh as the Bob command.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
REVIEW_FILE="$REPO_ROOT/bobshell-deep-review.md"

rm -rf "$REPO_ROOT/.bobshell" "$REVIEW_FILE"

chmod +x "$REPO_ROOT/scripts/bobshell-deep-review.sh" "$REPO_ROOT/tests/mock-bobshell.sh"

export BOBSHELL_RULES_LOCAL_PATH="$REPO_ROOT/bobshell-rules"
export BOBSHELL_COMMAND="'$REPO_ROOT/tests/mock-bobshell.sh'"
export FILE_PATTERN="**/*.py"

"$REPO_ROOT/scripts/bobshell-deep-review.sh"

test -f "$REVIEW_FILE"
grep -q "Deep Branch Review Report" "$REVIEW_FILE"

printf 'Deep review local test passed.\n'

#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
REVIEW_FILE="$REPO_ROOT/bobshell-review.md"

rm -rf "$REPO_ROOT/.bobshell" "$REVIEW_FILE"

chmod +x "$REPO_ROOT/scripts/bobshell-pr-review.sh" "$REPO_ROOT/tests/mock-bobshell.sh"

export BOBSHELL_RULES_LOCAL_PATH="$REPO_ROOT/bobshell-rules"
export BOBSHELL_DIFF_FILE="$REPO_ROOT/tests/fixtures/sample.diff"
export BOBSHELL_COMMAND="'$REPO_ROOT/tests/mock-bobshell.sh'"
export BOBSHELL_OUTPUT_MODE="artifact"
export BOBSHELL_REVIEW_FILE="$REVIEW_FILE"
export BOBSHELL_FAIL_ON="never"

"$REPO_ROOT/scripts/bobshell-pr-review.sh"

test -f "$REVIEW_FILE"
grep -q "Mock BobShell Review" "$REVIEW_FILE"
grep -q "Severity: high" "$REVIEW_FILE"
test -f "$REPO_ROOT/.bobshell/prompt.md"
grep -q "security.md" "$REPO_ROOT/.bobshell/prompt.md"

printf 'Local BobShell POC test passed.\n'
